from pathlib import Path
from app.ingestion.realtime import download_feed

def test_realtime_unknown_feed(tmp_path):
    try:
        download_feed('bad',tmp_path)
    except ValueError:
        return
    assert False
