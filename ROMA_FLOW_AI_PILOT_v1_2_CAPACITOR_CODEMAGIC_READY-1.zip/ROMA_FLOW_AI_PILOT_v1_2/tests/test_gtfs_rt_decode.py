from app.ingestion.gtfs_rt_decode import decode_feed, summarise_realtime

def vi(n:int)->bytes:
    out=b''
    while True:
        b=n & 0x7f; n >>= 7
        if n: out += bytes([b|0x80])
        else: out += bytes([b]); return out

def fld(n,wt,v):
    key=vi((n<<3)|wt)
    if wt==0: return key+vi(v)
    if wt==2: return key+vi(len(v))+v
    if wt==5: return key+v
    raise AssertionError

def msg(*parts): return b''.join(parts)

def test_trip_update_decode():
    trip=msg(fld(1,2,b'TRIP1'),fld(2,2,b'R1'))
    stu_event=fld(1,0,120)
    stu=msg(fld(4,2,b'STOP1'),fld(2,2,stu_event))
    update=msg(fld(1,2,trip),fld(2,2,stu),fld(5,0,90))
    entity=msg(fld(1,2,b'e1'),fld(3,2,update))
    feed=msg(fld(1,2,fld(1,2,b'2.0').rstrip(b'')),fld(2,2,entity))
    decoded=decode_feed(feed,'trip_updates')
    assert decoded['entity_count']==1
    summary=summarise_realtime(decoded,'trip_updates')
    assert summary['avg_delay_sec']==105.0
    assert summary['max_delay_sec']==120
    assert summary['routes_affected']==1
    assert summary['stops_mentioned']==1

def test_vehicle_position_decode():
    import struct
    pos=msg(fld(1,5,struct.pack('<f',41.9)),fld(2,5,struct.pack('<f',12.49)))
    trip=msg(fld(2,2,b'R1'))
    veh=msg(fld(1,2,trip),fld(2,2,pos))
    entity=msg(fld(1,2,b'v1'),fld(4,2,veh))
    feed=msg(fld(2,2,entity))
    decoded=decode_feed(feed,'vehicle_positions')
    summary=summarise_realtime(decoded,'vehicle_positions')
    assert summary['vehicles']==1
    assert summary['positioned_vehicles']==1
    assert summary['routes_active']==1
