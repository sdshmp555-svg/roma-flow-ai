from pathlib import Path
import pandas as pd
from app.services.forecast_calibration import calibrate, _add_temporal_features, _add_realtime_proxy_features

def test_temporal_features_no_crash():
    df=pd.read_csv(Path('data/tourism_timeseries.csv')).head(500)
    out=_add_realtime_proxy_features(_add_temporal_features(df))
    assert {'lag_1h','lag_24h','rolling_24h_mean','rolling_7d_mean','realtime_delay_sec','disruption_score','realtime_access_score'} <= set(out.columns)

def test_calibration_report(tmp_path):
    p=tmp_path/'report.json'
    report=calibrate(Path('data/tourism_timeseries.csv'), p)
    assert p.exists()
    assert report['train_rows'] > 0 and report['test_rows'] > 0
    assert report['baseline_mae'] >= 0 and report['enhanced_mae'] >= 0
