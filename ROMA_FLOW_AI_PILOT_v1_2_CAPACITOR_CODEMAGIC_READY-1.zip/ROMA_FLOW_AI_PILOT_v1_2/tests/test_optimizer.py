from app.services.optimizer import optimise

def test_optimizer_avoids_secondary_congestion():
    source={"asset_id":"SOURCE","pressure":0.97,"lat":41.90,"lon":12.48}
    candidates=[
        {"asset_id":"GOOD","lat":41.89,"lon":12.47,"pressure":0.30,"strategic_priority":1.0,"relevance":0.9,"economic_opportunity":0.95,"accessibility":0.9},
        {"asset_id":"BAD","lat":41.91,"lon":12.48,"pressure":0.89,"strategic_priority":1.0,"relevance":0.9,"economic_opportunity":0.95,"accessibility":0.9},
    ]
    out=optimise(source,candidates)
    ids=[x["asset_id"] for x in out["recommendations"]]
    assert "GOOD" in ids
    assert "BAD" not in ids
