from pathlib import Path
import io, zipfile
import pandas as pd
from app.services.geospatial import haversine_m, build_asset_mobility_profile


def test_haversine_zero():
    assert haversine_m(41.9,12.48,41.9,12.48)==0

def test_asset_profile():
    stops=pd.DataFrame([
      {'stop_id':'S1','stop_lat':41.9008,'stop_lon':12.4832},
      {'stop_id':'S2','stop_lat':41.9050,'stop_lon':12.4832},
      {'stop_id':'S3','stop_lat':41.9500,'stop_lon':12.5000},
    ])
    stop_times=pd.DataFrame([{'stop_id':'S1','trip_id':'T1'},{'stop_id':'S1','trip_id':'T2'},{'stop_id':'S2','trip_id':'T3'}])
    trips=pd.DataFrame([{'trip_id':'T1','route_id':'R1'},{'trip_id':'T2','route_id':'R2'},{'trip_id':'T3','route_id':'R2'}])
    assets=[{'asset_id':'A1','lat':41.9009,'lon':12.4833}]
    out=build_asset_mobility_profile(assets,stops,stop_times,trips,radius_m=700)
    row=out.iloc[0]
    assert row.nearby_stops==2
    assert row.nearby_routes==3
    assert 0 <= row.mobility_access_score <= 1
