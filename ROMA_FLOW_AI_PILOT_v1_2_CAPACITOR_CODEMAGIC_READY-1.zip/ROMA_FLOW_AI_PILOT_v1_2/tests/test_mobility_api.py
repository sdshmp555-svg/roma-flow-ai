from app.main import app
from fastapi.testclient import TestClient
from app.db import Base, engine, SessionLocal
from app.models.mobility import MobilityAssetSnapshot
from datetime import datetime

client=TestClient(app)

def test_city_mobility_endpoint():
    Base.metadata.create_all(bind=engine)
    db=SessionLocal()
    try:
        db.add(MobilityAssetSnapshot(asset_id='TRV_TREVI',ts=datetime.utcnow(),nearby_stops=2,nearby_routes=3,nearest_stop_m=15.0,mobility_access_score=.4))
        db.commit()
    finally:
        db.close()
    r=client.get('/api/v1/mobility/city')
    assert r.status_code==200
    assert r.json()['assets']
