from fastapi.testclient import TestClient
from app.main import app


def test_health():
    with TestClient(app) as client:
        r=client.get('/health')
        assert r.status_code==200
        assert r.json()['status']=='ok'


def test_forecast():
    with TestClient(app) as client:
        r=client.get('/api/v1/forecast',params={'asset_id':'TRV_TREVI','date':'2026-09-18','hour':17})
        assert r.status_code==200
        data=r.json()
        assert data['asset_id']=='TRV_TREVI'
        assert data['predicted_demand']>=0


def test_recommendation():
    with TestClient(app) as client:
        r=client.get('/api/v1/recommendations',params={'asset_id':'TRV_TREVI','date':'2026-09-18','hour':17})
        assert r.status_code==200
        assert 'recommendations' in r.json()
