from pathlib import Path
import pandas as pd
from app.services.spatial_realtime import build_spatial_realtime_features


def test_spatial_features_from_static_gtfs(tmp_path):
    gtfs = Path('/mnt/data/roma_flow_build/data/raw/gtfs')
    rt = tmp_path/'rt'; rt.mkdir()
    # Empty RT inputs are valid for a baseline snapshot.
    assets=[{'asset_id':'a1','lat':41.900,'lon':12.500,'zone_id':'z1','name':'A1','asset_type':'heritage','capacity':100,'priority':0.8}]
    df=build_spatial_realtime_features(gtfs,rt,assets=assets,radius_m=1500)
    assert len(df)==1
    row=df.iloc[0]
    assert row['asset_id']=='a1'
    assert row['nearby_stop_count']>0
    assert 0<=row['realtime_access_score']<=1
    assert 0<=row['disruption_score']<=1
