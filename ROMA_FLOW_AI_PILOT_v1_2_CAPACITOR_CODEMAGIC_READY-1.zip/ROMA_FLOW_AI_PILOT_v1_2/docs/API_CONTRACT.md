# Core API contract — v1.2

## City intelligence
`GET /api/v1/city-status?date=YYYY-MM-DD&hour=17`

Returns all monitored assets with forecast demand, capacity, pressure label and location.

## Forecast
`GET /api/v1/forecast?asset_id=TRV_TREVI&date=YYYY-MM-DD&hour=17`

Returns demand forecast, pressure, model version and hold-out error metrics.

## Recommendations
`GET /api/v1/recommendations?asset_id=TRV_TREVI&date=YYYY-MM-DD&hour=17`

Returns ranked alternative destinations plus score, capacity, distance and human-readable rationale.

## Pilot simulation
`GET /api/v1/pilot/simulate?asset_id=TRV_TREVI&date=YYYY-MM-DD&hour=17&diversion=20`

Decision-support simulation for a hypothetical diversion quantity. The output is not a measured outcome.

## Capacity
`GET /api/v1/capacity`

Returns current demo/partner inventory snapshots.

## Data sources
`GET /api/v1/data/sources`

Returns source registry and connector status.

## Production readiness
`GET /api/v1/production/readiness`

Returns deployment status and hardening expectations.
