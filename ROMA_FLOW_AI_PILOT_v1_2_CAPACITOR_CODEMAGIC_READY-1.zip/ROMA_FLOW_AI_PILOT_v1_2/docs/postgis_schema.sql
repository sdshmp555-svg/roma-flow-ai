CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS assets (
  id TEXT PRIMARY KEY,
  zone_id TEXT NOT NULL,
  name TEXT NOT NULL,
  asset_type TEXT NOT NULL,
  lat DOUBLE PRECISION NOT NULL,
  lon DOUBLE PRECISION NOT NULL,
  geometry geometry(Point,4326) GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(lon,lat),4326)) STORED,
  nominal_capacity INTEGER NOT NULL,
  strategic_priority DOUBLE PRECISION NOT NULL DEFAULT 0.5,
  relevance_score DOUBLE PRECISION NOT NULL DEFAULT 0.7,
  economic_opportunity DOUBLE PRECISION NOT NULL DEFAULT 0.5,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS capacity_snapshots (
  id BIGSERIAL PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES assets(id),
  ts TIMESTAMPTZ NOT NULL,
  capacity INTEGER NOT NULL,
  booked INTEGER NOT NULL,
  available INTEGER NOT NULL,
  price_eur NUMERIC(10,2) NOT NULL DEFAULT 0,
  source TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS capacity_asset_ts_idx ON capacity_snapshots(asset_id, ts DESC);

CREATE TABLE IF NOT EXISTS knowledge_edges (
  id BIGSERIAL PRIMARY KEY,
  source_id TEXT NOT NULL,
  target_id TEXT NOT NULL,
  relation TEXT NOT NULL,
  weight DOUBLE PRECISION NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS knowledge_source_idx ON knowledge_edges(source_id);

CREATE TABLE IF NOT EXISTS recommendation_logs (
  id BIGSERIAL PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL,
  source_asset_id TEXT NOT NULL,
  target_asset_id TEXT NOT NULL,
  score DOUBLE PRECISION NOT NULL,
  executed BOOLEAN NOT NULL DEFAULT FALSE,
  diverted_visitors INTEGER NOT NULL DEFAULT 0,
  rationale TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS mobility_asset_snapshots (
  id BIGSERIAL PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES assets(id),
  ts TIMESTAMPTZ NOT NULL,
  nearby_stops INTEGER NOT NULL,
  nearby_routes INTEGER NOT NULL,
  nearest_stop_m DOUBLE PRECISION NOT NULL,
  mobility_access_score DOUBLE PRECISION NOT NULL
);

CREATE TABLE IF NOT EXISTS realtime_mobility_snapshots (
  id BIGSERIAL PRIMARY KEY,
  kind TEXT NOT NULL,
  retrieved_at TIMESTAMPTZ NOT NULL,
  entity_count INTEGER NOT NULL DEFAULT 0,
  avg_delay_sec DOUBLE PRECISION NOT NULL DEFAULT 0,
  max_delay_sec DOUBLE PRECISION NOT NULL DEFAULT 0,
  routes_affected INTEGER NOT NULL DEFAULT 0,
  stops_affected INTEGER NOT NULL DEFAULT 0,
  positioned_vehicles INTEGER NOT NULL DEFAULT 0,
  vehicles INTEGER NOT NULL DEFAULT 0,
  alerts INTEGER NOT NULL DEFAULT 0
);
