# ROMA FLOW AI — Data Ingestion Stage

## Implemented

### 1. Roma Mobilità GTFS static connector
- Official static GTFS URL is configured in `app/ingestion/roma_mobilita.py`.
- The connector downloads the official ZIP, computes SHA-256, parses `stops`, `routes`, `trips`, and `stop_times`, and stores normalized CSV snapshots.
- The official source says the static GTFS is updated almost daily.
- Real-time trip updates, vehicle positions and service alerts are published separately and are updated about every 60 seconds; these URLs are already defined as constants for the next ingestion module.

### 2. Weather connector
- Open-Meteo hourly forecast connector for Rome is implemented.
- It is deliberately isolated behind a small function so the source can be replaced later without changing the forecasting engine.

### 3. Ingestion registry
Every run can be recorded in `ingestion_runs` with:
- source
- status
- timestamps
- bytes downloaded
- SHA-256
- summary
- error message

### 4. API
- `GET /api/v1/ingestion/status`
- `POST /api/v1/ingestion/gtfs-static`
- `GET /api/v1/ingestion/weather`

### 5. CLI
```bash
PYTHONPATH=. python scripts/ingest_data.py --source gtfs
PYTHONPATH=. python scripts/ingest_data.py --source weather
PYTHONPATH=. python scripts/ingest_data.py --source all
```

## Important production rule
The ingestion layer does not silently treat a failed source as valid data. Each source returns a status and the error is persisted. Downstream models should use source-quality checks before accepting a new snapshot.

## Current limitation
This build is ready for live retrieval, but the execution container used for development has no outbound DNS/network access. Therefore the live download itself was not executed here; parser behavior and ingestion bookkeeping were tested locally with a GTFS fixture.
