# Production hardening checklist

- [ ] Put the service behind HTTPS/reverse proxy.
- [ ] Add authentication/RBAC for city and partner dashboards.
- [ ] Store secrets in environment/secret manager.
- [ ] Restrict CORS to approved origins.
- [ ] Add request rate limits and audit logs.
- [ ] Encrypt partner data in transit and at rest.
- [ ] Formalise data retention/deletion policy.
- [ ] Complete DPIA/GDPR review before live partner data ingestion.
- [ ] Add monitoring/alerting and database backups.
- [ ] Run dependency vulnerability scanning in CI.
