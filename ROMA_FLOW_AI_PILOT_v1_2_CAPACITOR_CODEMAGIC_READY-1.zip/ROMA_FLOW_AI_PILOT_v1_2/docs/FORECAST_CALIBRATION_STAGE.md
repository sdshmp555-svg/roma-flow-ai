# ROMA FLOW AI — v0.6 Forecast Calibration

## Objective
Evaluate whether temporal, mobility and realtime feature-store signals add predictive value beyond a tourism-only baseline.

## Models
- Baseline: calendar/weather/event/capacity/history + temporal lags and rolling means.
- Enhanced: Baseline + mobility_index + realtime_delay_sec + nearby_delayed_route_count + nearby_alert_count + active_vehicle_count + disruption_score + realtime_access_score.

## Validation
Time-based holdout: latest 30 days of the synthetic 365-day dataset. Metrics: MAE and RMSE.

## Current synthetic result
- Baseline MAE: 15.9943
- Enhanced MAE: 15.9331
- MAE improvement: 0.3827%
- Baseline RMSE: 28.1363
- Enhanced RMSE: 27.9974
- RMSE improvement: 0.4939%
- Train rows: 75,375
- Test rows: 6,750

## Interpretation
The improvement is deliberately treated as an engineering signal, not a real-world claim. The realtime columns are calibration proxies generated from the synthetic `mobility_index`. In the pilot, these fields must be joined from the real spatial realtime feature store and evaluated again.

## Acceptance gate for the next stage
Proceed only after live-data calibration is run with the same time-split method and documented data lineage.
