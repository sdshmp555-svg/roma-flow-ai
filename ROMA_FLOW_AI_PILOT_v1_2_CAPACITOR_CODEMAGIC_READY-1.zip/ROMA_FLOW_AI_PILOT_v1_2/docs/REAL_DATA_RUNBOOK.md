# Live data runbook

1. Ensure the deployment has outbound HTTPS access.
2. Run `python scripts/ingest_data.py` for static GTFS.
3. Run `python scripts/ingest_realtime.py --feed trip_updates` (repeat for vehicle_positions and service_alerts).
4. Run `curl -X POST http://localhost:8000/api/v1/ingestion/weather`.
5. Run `curl -X POST http://localhost:8000/api/v1/mobility/profile` and spatial/realtime feature jobs from the prior stage where needed.
6. Review `/api/v1/ingestion/status` and verify checksums, timestamps and source status.
7. Train/refresh Forecast v1 after sufficient real historical features are available. Do not train on synthetic proxies once real features exist.
