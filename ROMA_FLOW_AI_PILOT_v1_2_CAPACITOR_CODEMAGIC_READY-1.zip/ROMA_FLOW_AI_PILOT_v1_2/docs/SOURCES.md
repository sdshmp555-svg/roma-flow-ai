# Verified public data sources used by ROMA FLOW AI

## Rome public transport
Roma Servizi per la Mobilità states that its GTFS static dataset is updated almost daily, while the two real-time vehicle/trip feeds are updated about every 60 seconds; service alerts are published in a separate GTFS-Realtime feed.

Official source: https://romamobilita.it/sistemi-e-tecnologie/open-data/

## Official tourism information
TurismoRoma is the official tourism portal of Roma Capitale and describes its information ecosystem and the 060608 tourism/culture/entertainment information service.

Official source: https://www.turismoroma.it/it/chi-siamo
FAQ/data context: https://www.turismoroma.it/it/pagina/faq

## Weather
Open-Meteo provides forecast and historical weather APIs. Its documentation states that its historical weather API can provide hourly data and that no API key is required for standard non-reserved use; commercial/reserved resources may require an API key.

Official source: https://open-meteo.com/
Historical API: https://open-meteo.com/en/docs/historical-weather-api
Historical Forecast API: https://open-meteo.com/en/docs/historical-forecast-api

## Important data-governance note
ROMA FLOW AI uses these sources as configurable connectors, not as a claim of unrestricted access to every field. Where a source requires permission, partnership, rate limits, licensing or a dedicated feed, the production deployment must comply with those terms.
