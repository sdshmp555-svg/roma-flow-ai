# ROMA FLOW AI v1.2 implementation status

| Layer | Status |
|---|---|
| Data ingestion | Implemented; verified public-source connectors + ingestion registry |
| GTFS static | Implemented |
| GTFS-Realtime | Implemented with standard binary decoder + fixture tests |
| Weather | Implemented connector |
| Geospatial mobility | Implemented |
| Spatial realtime feature store | Implemented |
| Temporal feature engineering | Implemented |
| Forecast v1 | Implemented and trained on deterministic development data |
| Knowledge graph | Implemented as relational graph edges |
| Capacity engine | Implemented; partner-feed-ready schema |
| Flow optimisation | Implemented with secondary-congestion guard |
| Recommendation engine | Implemented with rationale + logging |
| Pilot simulation | Implemented |
| City dashboard | Implemented as responsive web app served by FastAPI |
| API documentation | FastAPI `/docs` + API contract |
| Docker | Implemented |
| PostgreSQL/PostGIS target schema | Included |
| Authentication/RBAC | Production hardening checklist; not included in this local prototype |
| Live data execution | Connector-ready; deployment requires outbound network and any required source permissions |

Synthetic data remains only a development fixture. Before a real city pilot, historical and operational datasets must be replaced/augmented with governed real data and the model must be recalibrated on those observations.
