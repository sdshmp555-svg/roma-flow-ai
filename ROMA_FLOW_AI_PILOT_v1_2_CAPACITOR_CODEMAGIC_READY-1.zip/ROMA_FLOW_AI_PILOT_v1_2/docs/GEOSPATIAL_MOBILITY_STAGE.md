# ROMA FLOW AI — Stage v0.3: Geospatial Mobility Intelligence

## Goal
Turn Rome public-transport data into an asset-level accessibility signal that can feed forecasting and redistribution decisions.

## Implemented
- Haversine distance engine.
- GTFS stop-to-asset spatial matching.
- Nearby stop count within configurable radius.
- Nearby route count using GTFS `stop_times` + `trips` joins.
- Asset-level `mobility_access_score` in [0,1].
- Persistent `mobility_asset_snapshots` table.
- `/api/v1/mobility/profile` to build a profile from the ingested static GTFS.
- `/api/v1/mobility/asset/{asset_id}` for one asset.
- `/api/v1/mobility/city` for city-wide profiles.
- Realtime feed paths prepared for trip updates, vehicle positions and service alerts.

## Design rule
The mobility score is not itself a crowd score. It is a contextual accessibility/service signal. It becomes a feature for the forecasting and optimisation layers.

## Production data contract
Rome Mobility publishes static GTFS and three GTFS-realtime binary feeds. Static GTFS is updated nearly daily; realtime trip updates and vehicle positions are updated about every 60 seconds. The source notes that the data is intended to support travel information and can be affected by operational variability, so ROMA FLOW should score freshness/reliability and avoid treating a raw feed as ground truth.
