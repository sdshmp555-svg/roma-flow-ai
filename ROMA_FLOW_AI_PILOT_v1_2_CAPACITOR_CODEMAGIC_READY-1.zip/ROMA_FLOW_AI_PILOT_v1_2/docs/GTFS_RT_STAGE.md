# ROMA FLOW AI — GTFS-Realtime Integration Stage

This stage upgrades the mobility layer from raw GTFS-Realtime binary downloads to parsed operational signals.

## Supported feeds
- `trip_updates`: delay, route and stop signals.
- `vehicle_positions`: active vehicles, route association and positions.
- `service_alerts`: affected routes/stops and alert counts.

## Design choice
The MVP includes a small protobuf wire-level decoder for only the GTFS-Realtime fields required by ROMA FLOW. This keeps the prototype self-contained while remaining compatible with the standard binary wire format. A generated official binding can replace it later without changing the service contract.

## Decision impact
Realtime quality is converted into a city-level `realtime_quality` factor derived from observed delays and service-alert volume. In the MVP it contributes 20% of the accessibility sub-score used by the recommendation engine.

This is intentionally conservative: realtime mobility is one signal among several and cannot override destination capacity, relevance or congestion relief.

## APIs
- `POST /api/v1/ingestion/gtfs-realtime/{feed}`
- `GET /api/v1/mobility/realtime-status`
- `GET /api/v1/recommendations`

## Production hardening later
- protobuf schema validation against official generated bindings
- stop/route spatial join for alert propagation
- vehicle position density by tourism zone
- route-specific delay models
- event-time rather than retrieval-time alignment
- retention policy for raw binaries and parsed snapshots
