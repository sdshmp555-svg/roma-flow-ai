# ROMA FLOW AI — Spatial Real-Time Feature Store v0.5

## Goal
Translate GTFS-Realtime signals from feed-level summaries into attraction-level features that can influence forecasts and redistribution recommendations.

## Spatial mapping
- Each ROMA FLOW asset is mapped to its nearest GTFS stop.
- Nearby stops are counted within a configurable radius (default 800 m).
- Realtime delay and service-alert signals are aggregated around those nearby stops and routes.

## Feature set
- realtime_delay_sec
- affected_route_count
- affected_stop_count
- service_alert_count
- active_vehicle_count
- nearby_delayed_route_count
- nearby_alert_count
- realtime_access_score
- disruption_score

## Decision impact
`realtime_access_score` is mixed into recommendation accessibility, so disruptions can lower the ranking of an otherwise attractive alternative.

## MVP limitation
Route-to-stop spatial attribution is conservative until the full static GTFS stop_times/route mapping is used to build a production route coverage graph. The current stage prioritises transparent, testable features over hidden inference.

## Next calibration
The next step should train the demand model with temporal mobility features and compare forecast accuracy with/without realtime signals.
