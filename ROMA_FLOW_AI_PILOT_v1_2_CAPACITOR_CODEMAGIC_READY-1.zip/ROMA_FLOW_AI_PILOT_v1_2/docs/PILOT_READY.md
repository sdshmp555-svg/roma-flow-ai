# ROMA FLOW AI v1.2 — Pilot Ready

## Scope completed
- Real-source connector layer for Roma Mobilità GTFS and GTFS-Realtime.
- Open-Meteo weather connector.
- Tourism asset knowledge graph (relational graph with explicit edges).
- Capacity engine with partner-feed-ready schema and demo seed.
- Forecast v1 with temporal and mobility/realtime feature contract.
- Flow optimisation with secondary-congestion guard.
- Recommendation engine with explicit rationale.
- Pilot intervention simulator using before/after decision-support estimates.
- API layer and responsive city dashboard.
- Docker and production configuration.
- Ingestion registry and provenance metadata.

## Live data caveat
This environment does not have outbound internet access during build/test. The connectors point to the verified official source URLs, and the parsers are tested locally with fixtures. The first deployment with network access should run the ingestion commands and record the live snapshots.

## Pilot boundary
Recommended first pilot: 2–3 zones, 3–5 tour operators, 10–15 attractions/experiences, 5–7 data families, daily/intra-day forecasting, city dashboard + operator recommendation panel.

## Privacy
The design does not require individual tourist profiling. Prefer aggregated/anonymised mobility and demand signals; maintain source provenance and role-based access in production.
