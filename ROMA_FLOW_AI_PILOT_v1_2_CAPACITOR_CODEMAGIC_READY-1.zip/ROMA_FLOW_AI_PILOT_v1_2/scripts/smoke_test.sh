#!/usr/bin/env bash
set -euo pipefail
python scripts/generate_dataset.py
python scripts/train_model.py
pytest -q
