from __future__ import annotations
import argparse, json
from pathlib import Path
from app.services.realtime import ingest_and_summarise
from app.ingestion.registry import record_run

parser=argparse.ArgumentParser()
parser.add_argument('--feed', choices=['trip_updates','vehicle_positions','service_alerts','all'], default='all')
args=parser.parse_args()
feeds=['trip_updates','vehicle_positions','service_alerts'] if args.feed=='all' else [args.feed]
for feed in feeds:
    result=ingest_and_summarise(feed, Path('data/raw/realtime'))
    record_run(result['source'], result['status'], bytes_downloaded=result.get('bytes_downloaded',0), sha256=result.get('sha256'), summary_json=json.dumps(result.get('summary')) if result.get('summary') else None, error=result.get('error'))
    print(json.dumps(result, indent=2))
