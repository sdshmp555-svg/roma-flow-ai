import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import subprocess, sys
steps=[
 [sys.executable,'scripts/generate_dataset.py'],
 [sys.executable,'scripts/train_v1.py'],
]
for cmd in steps:
    subprocess.run(cmd,check=True)
print('Local refresh complete. Use the API/cron for live ingestion connectors.')
