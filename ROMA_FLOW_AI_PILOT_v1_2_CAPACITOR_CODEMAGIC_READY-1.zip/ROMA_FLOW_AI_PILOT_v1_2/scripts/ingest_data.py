from __future__ import annotations
import argparse
import json
from pathlib import Path
from app.ingestion.registry import record_run
from app.ingestion.roma_mobilita import ingest_static_gtfs
from app.ingestion.weather import fetch_weather


def main():
    parser=argparse.ArgumentParser(description='ROMA FLOW AI data ingestion runner')
    parser.add_argument('--source', choices=['gtfs','weather','all'], default='all')
    args=parser.parse_args()
    results=[]
    if args.source in ('gtfs','all'):
        result=ingest_static_gtfs(Path('data')/'raw'/'gtfs')
        record_run(result['source'], result['status'], bytes_downloaded=result.get('bytes_downloaded',0),
                   sha256=result.get('checksum_sha256'), summary_json=json.dumps(result.get('summary')) if result.get('summary') else None,
                   error=result.get('error'))
        results.append(result)
    if args.source in ('weather','all'):
        try:
            payload=fetch_weather()
            result={'source':'open_meteo_weather','status':'ok','hours':len(payload.get('hourly',{}).get('time',[]))}
        except Exception as exc:
            result={'source':'open_meteo_weather','status':'error','error':str(exc)}
        record_run(result['source'], result['status'], summary_json=json.dumps(result), error=result.get('error'))
        results.append(result)
    print(json.dumps(results, indent=2, ensure_ascii=False))

if __name__=='__main__':
    main()
