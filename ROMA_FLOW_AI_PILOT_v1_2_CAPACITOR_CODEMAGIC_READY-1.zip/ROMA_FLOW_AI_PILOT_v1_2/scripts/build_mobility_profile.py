from pathlib import Path
from app.db import Base, SessionLocal, engine
from app.models.mobility import MobilityAssetSnapshot
from app.services.mobility import compute_asset_mobility

Base.metadata.create_all(bind=engine)
df=compute_asset_mobility(Path('data/raw/gtfs'))
db=SessionLocal()
try:
    df2=df.drop(columns=['ts'])
    for r in df.to_dict(orient='records'):
        db.add(MobilityAssetSnapshot(asset_id=r['asset_id'], ts=r['ts'], nearby_stops=int(r['nearby_stops']), nearby_routes=int(r['nearby_routes']), nearest_stop_m=float(r['nearest_stop_m']), mobility_access_score=float(r['mobility_access_score'])))
    db.commit()
    print(df2.to_string(index=False))
finally:
    db.close()
