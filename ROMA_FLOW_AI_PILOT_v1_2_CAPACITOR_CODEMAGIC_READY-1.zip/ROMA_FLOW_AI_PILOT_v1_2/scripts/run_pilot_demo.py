import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from fastapi.testclient import TestClient
from app.main import app

with TestClient(app) as client:
    print(client.get('/api/v1/pilot/simulate?asset_id=TRV_TREVI&date=2026-09-18&hour=17&diversion=20').json())
