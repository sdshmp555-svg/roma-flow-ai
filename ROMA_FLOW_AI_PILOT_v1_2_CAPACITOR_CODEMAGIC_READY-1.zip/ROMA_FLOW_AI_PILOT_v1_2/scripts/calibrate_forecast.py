import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.config import DATASET_PATH, DATA_DIR
from app.services.forecast_calibration import calibrate
print(calibrate(DATASET_PATH, DATA_DIR / 'forecast_calibration_report.json'))
