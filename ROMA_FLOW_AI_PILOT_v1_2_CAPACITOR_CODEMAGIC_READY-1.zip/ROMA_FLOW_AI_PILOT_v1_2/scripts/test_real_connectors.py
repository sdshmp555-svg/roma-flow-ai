from __future__ import annotations
import io, zipfile, pandas as pd
from app.ingestion.roma_mobilita import parse_gtfs_static, summarise_gtfs


def make_fixture() -> bytes:
    files = {
        "stops.txt": "stop_id,stop_name,stop_lat,stop_lon\nS1,Trevi,41.9000,12.4833\nS2,Monti,41.8950,12.4900\n",
        "routes.txt": "route_id,route_short_name,route_long_name\nR1,1,Demo Route\n",
        "trips.txt": "route_id,service_id,trip_id\nR1,WD,T1\n",
        "stop_times.txt": "trip_id,arrival_time,departure_time,stop_id,stop_sequence\nT1,17:00:00,17:01:00,S1,1\nT1,17:05:00,17:06:00,S2,2\n",
    }
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        for name, content in files.items(): z.writestr(name,content)
    return buf.getvalue()


def main():
    tables=parse_gtfs_static(make_fixture())
    summary=summarise_gtfs(tables)
    assert summary["stops"]==2
    assert summary["routes"]==1
    assert summary["trips"]==1
    assert summary["stop_time_rows"]==2
    print("GTFS parser smoke test: PASS", summary)

if __name__=='__main__': main()
