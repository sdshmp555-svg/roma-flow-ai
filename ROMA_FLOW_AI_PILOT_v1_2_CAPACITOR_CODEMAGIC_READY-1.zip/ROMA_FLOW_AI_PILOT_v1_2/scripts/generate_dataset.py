import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.services.data_generator import generate_history

df=generate_history()
print(f"Generated {len(df):,} rows -> data/tourism_timeseries.csv")
print(df.head(5).to_string(index=False))
