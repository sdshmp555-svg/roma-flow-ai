from __future__ import annotations
from datetime import date, datetime
from pathlib import Path
import json
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy import select
from app.config import DATASET_PATH, MODEL_PATH, STATIC_DIR
from app.db import Base, engine, SessionLocal
from app.models.domain import Asset
from app.models.mobility import MobilityAssetSnapshot, RealtimeMobilitySnapshot
from app.models.spatial_realtime import SpatialRealtimeFeature
from app.ingestion.registry import IngestionRun, record_run
from app.ingestion.roma_mobilita import ingest_static_gtfs
from app.ingestion.realtime import download_feed
from app.ingestion.weather import fetch_weather
from app.services.data_generator import ASSETS, generate_history
from app.services.model_v1 import train_v1
from app.services.prediction import forecast
from app.services.capacity import seed_capacity, capacity_map
from app.services.knowledge import seed_knowledge_graph, graph_for_asset
from app.services.recommendation import build_recommendations
from app.services.pilot import simulate_intervention
from app.services.production import readiness
from app.services.forecast_calibration import calibrate

@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(bind=engine)
    if not DATASET_PATH.exists(): generate_history()
    db=SessionLocal()
    try:
        if db.query(Asset).count()==0:
            for a in ASSETS:
                db.add(Asset(id=a['asset_id'],zone_id=a['zone_id'],name=a['name'],asset_type=a['asset_type'],lat=a['lat'],lon=a['lon'],nominal_capacity=a['capacity'],strategic_priority=a['priority'],relevance_score=min(1,0.55+a['priority']*0.35),economic_opportunity=min(1,0.45+a['priority']*0.5)))
            db.commit()
    finally: db.close()
    if not MODEL_PATH.exists(): train_v1()
    seed_capacity(); seed_knowledge_graph()
    yield

app=FastAPI(title='ROMA FLOW AI',version='1.2.0',description='Pilot-ready predictive tourism flow management platform',lifespan=lifespan)
app.mount('/static', StaticFiles(directory=str(STATIC_DIR / 'static')), name='static')

@app.get('/')
def dashboard():
    index=STATIC_DIR/'index.html'
    return FileResponse(index)


@app.get('/manifest.webmanifest')
def manifest():
    return FileResponse(STATIC_DIR / 'manifest.webmanifest', media_type='application/manifest+json')

@app.get('/sw.js')
def service_worker():
    return FileResponse(STATIC_DIR / 'sw.js', media_type='application/javascript')

@app.get('/health')
def health():
    return {'status':'ok','service':'roma-flow-ai','version':'1.2.0','dataset_ready':DATASET_PATH.exists(),'model_ready':MODEL_PATH.exists()}

@app.get('/api/v1/production/readiness')
def production_readiness(): return readiness()

@app.get('/api/v1/data/sources')
def data_sources():
    return {'sources':[
        {'id':'roma_gtfs','name':'Roma Mobilità GTFS','type':'scheduled','refresh':'near-daily','status':'connector-ready'},
        {'id':'roma_gtfs_rt','name':'Roma Mobilità GTFS-Realtime','type':'realtime','refresh':'~60 seconds','status':'connector-ready'},
        {'id':'open_meteo','name':'Open-Meteo','type':'weather','refresh':'forecast / hourly','status':'connector-ready'},
        {'id':'partner_inventory','name':'Partner booking/capacity feed','type':'commercial','refresh':'partner-defined','status':'schema-ready'},
        {'id':'tourism_official','name':'Official tourism/events feeds','type':'context','refresh':'source-defined','status':'integration-ready'}]}

@app.get('/api/v1/city-status')
def city_status(date_value:date=Query(...,alias='date'),hour:int=Query(...,ge=8,le=22)):
    db=SessionLocal(); rows=[]
    try:
        for a in db.scalars(select(Asset).where(Asset.active==True)).all():
            f=forecast(a.id,date_value,hour); rows.append({**f,'name':a.name,'zone_id':a.zone_id,'lat':a.lat,'lon':a.lon,'asset_type':a.asset_type})
    finally: db.close()
    rows.sort(key=lambda r:r['pressure'],reverse=True)
    return {'date':date_value.isoformat(),'hour':hour,'hotspots':rows[:5],'all_assets':rows}

@app.get('/api/v1/forecast')
def get_forecast(asset_id:str,date_value:date=Query(...,alias='date'),hour:int=Query(...,ge=8,le=22)):
    try: return forecast(asset_id,date_value,hour)
    except KeyError: raise HTTPException(404,'Unknown asset')

@app.get('/api/v1/recommendations')
def recommendations(asset_id:str,date_value:date=Query(...,alias='date'),hour:int=Query(...,ge=8,le=22)):
    try: return build_recommendations(asset_id,date_value,hour)
    except KeyError: raise HTTPException(404,'Unknown asset')


@app.get('/api/v1/mobility/city')
def mobility_city():
    db=SessionLocal()
    try:
        rows=db.query(MobilityAssetSnapshot).order_by(MobilityAssetSnapshot.id.desc()).all()
        seen=set(); out=[]
        for r in rows:
            if r.asset_id in seen: continue
            seen.add(r.asset_id)
            out.append({'asset_id':r.asset_id,'ts':r.ts.isoformat(),'nearby_stops':r.nearby_stops,'nearby_routes':r.nearby_routes,'nearest_stop_m':r.nearest_stop_m,'mobility_access_score':r.mobility_access_score})
        return {'assets':out}
    finally: db.close()

@app.get('/api/v1/mobility/realtime-status')
def mobility_realtime_status(limit:int=Query(20,ge=1,le=200)):
    db=SessionLocal()
    try:
        rows=db.query(RealtimeMobilitySnapshot).order_by(RealtimeMobilitySnapshot.id.desc()).limit(limit).all()
        return {'snapshots':[{'id':r.id,'kind':r.kind,'retrieved_at':r.retrieved_at.isoformat(),'entity_count':r.entity_count,'avg_delay_sec':r.avg_delay_sec,'max_delay_sec':r.max_delay_sec,'routes_affected':r.routes_affected,'stops_affected':r.stops_affected,'positioned_vehicles':r.positioned_vehicles,'vehicles':r.vehicles,'alerts':r.alerts} for r in rows]}
    finally: db.close()

@app.get('/api/v1/capacity')
def capacity(): return {'assets':capacity_map()}

@app.post('/api/v1/capacity/seed')
def capacity_seed(): return seed_capacity()

@app.post('/api/v1/knowledge/seed')
def knowledge_seed(): return seed_knowledge_graph()

@app.get('/api/v1/knowledge/asset/{asset_id}')
def knowledge_asset(asset_id:str): return {'asset_id':asset_id,'edges':graph_for_asset(asset_id)}

@app.get('/api/v1/pilot/simulate')
def pilot_simulate(asset_id:str,date_value:date=Query(...,alias='date'),hour:int=Query(...,ge=8,le=22),diversion:int=Query(20,ge=5,le=50)):
    try: return simulate_intervention(asset_id,date_value,hour,diversion)
    except KeyError: raise HTTPException(404,'Unknown asset')

@app.get('/api/v1/kpis')
def kpis():
    db=SessionLocal()
    try:
        recs=db.query(__import__('app.models.domain',fromlist=['RecommendationLog']).RecommendationLog).all()
        executed=sum(1 for r in recs if r.executed)
        diverted=sum(int(r.diverted_visitors or 0) for r in recs if r.executed)
        return {'recommendations_generated':len(recs),'recommendations_executed':executed,'execution_rate':round(executed/len(recs),3) if recs else 0.0,'visitors_diverted':diverted,'cost_per_successful_recommendation_eur':None,'note':'Pilot metrics become measured once partner execution events are connected.'}
    finally: db.close()

@app.get('/api/v1/model/calibration')
def model_calibration():
    p=DATASET_PATH.parent/'forecast_calibration_report.json'
    if not p.exists(): return calibrate(DATASET_PATH,p)
    return json.loads(p.read_text())

@app.get('/api/v1/model/report')
def model_report():
    p=DATASET_PATH.parent/'forecast_v1_report.json'; return json.loads(p.read_text()) if p.exists() else train_v1()

@app.get('/api/v1/ingestion/status')
def ingestion_status(limit:int=Query(20,ge=1,le=200)):
    db=SessionLocal()
    try:
        rs=db.query(IngestionRun).order_by(IngestionRun.id.desc()).limit(limit).all()
        return {'runs':[{'id':r.id,'source':r.source,'status':r.status,'started_at':r.started_at.isoformat() if r.started_at else None,'finished_at':r.finished_at.isoformat() if r.finished_at else None,'bytes_downloaded':r.bytes_downloaded,'sha256':r.sha256,'summary':json.loads(r.summary_json) if r.summary_json else None,'error':r.error} for r in rs]}
    finally: db.close()

@app.post('/api/v1/ingestion/gtfs-static')
def ingest_gtfs():
    result=ingest_static_gtfs(Path('data/raw/gtfs'))
    record_run(result['source'],result['status'],bytes_downloaded=result.get('bytes_downloaded',0),sha256=result.get('checksum_sha256'),summary_json=json.dumps(result.get('summary')) if result.get('summary') else None,error=result.get('error'))
    return result

@app.post('/api/v1/ingestion/weather')
def weather():
    return fetch_weather()

@app.post('/api/v1/ingestion/gtfs-realtime/{feed}')
def realtime(feed:str):
    if feed not in ('trip_updates','vehicle_positions','service_alerts'): raise HTTPException(400,'Unsupported feed')
    result=download_feed(feed,Path('data/raw/realtime'))
    record_run(result['source'],result['status'],bytes_downloaded=result.get('bytes_downloaded',0),sha256=result.get('sha256'),summary_json=json.dumps(result.get('summary')) if result.get('summary') else None,error=result.get('error'))
    return result
