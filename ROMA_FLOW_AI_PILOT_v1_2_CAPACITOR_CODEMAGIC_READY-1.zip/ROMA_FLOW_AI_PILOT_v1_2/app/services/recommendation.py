from __future__ import annotations
from datetime import datetime, UTC
from app.services.optimizer import candidate_score, haversine_km
from app.services.capacity import capacity_map
from app.services.prediction import forecast
from app.db import SessionLocal
from app.models.domain import Asset, RecommendationLog
from sqlalchemy import select


def build_recommendations(source_id:str, date_value, hour:int, diversion_share:float=0.15):
    db=SessionLocal()
    try:
        assets=db.scalars(select(Asset).where(Asset.active==True)).all()
        byid={a.id:a for a in assets}
        source=byid.get(source_id)
        if not source: raise KeyError(source_id)
        sf=forecast(source_id,date_value,hour)
        if sf["pressure"]<0.85:
            return {"source":sf,"action":"monitor","recommendations":[]}
        caps=capacity_map(); scored=[]
        for c in assets:
            if c.id==source_id: continue
            cf=forecast(c.id,date_value,hour)
            cap=caps.get(c.id,{"available":max(0,c.nominal_capacity-int(c.nominal_capacity*0.5)),"occupancy":0.5,"price_eur":0})
            available_ratio=cap["available"]/max(1,c.nominal_capacity)
            # Reject secondary congestion and low availability.
            if cf["pressure"]>=0.85 or available_ratio<0.15: continue
            distance=haversine_km(source.lat,source.lon,c.lat,c.lon)
            travel_eff=max(0.0,1-distance/12)
            relief=max(0.0,min(1.0,(sf["pressure"]-0.60)/0.40))
            accessibility=c.relevance_score
            score=candidate_score(relief=relief,capacity_availability=available_ratio,relevance=c.relevance_score,economic_opportunity=c.economic_opportunity,accessibility=accessibility,travel_efficiency=travel_eff,strategic_priority=c.strategic_priority)
            rationale=(f"Relieves {source.name} pressure {sf['pressure']:.0%}; {c.name} projected pressure {cf['pressure']:.0%}; "
                       f"available capacity {available_ratio:.0%}; distance {distance:.1f} km; accessibility {accessibility:.2f}.")
            scored.append({"asset_id":c.id,"name":c.name,"zone_id":c.zone_id,"score":round(score,4),"projected_pressure":cf["pressure"],"available_capacity":cap["available"],"distance_km":round(distance,2),"price_eur":cap["price_eur"],"rationale":rationale})
        scored.sort(key=lambda x:x["score"], reverse=True)
        result={"source":sf,"action":"redistribute","recommendations":scored[:5]}
        now=datetime.now(UTC)
        for r in scored[:5]:
            db.add(RecommendationLog(created_at=now,source_asset_id=source_id,target_asset_id=r["asset_id"],score=r["score"],rationale=r["rationale"]))
        db.commit()
        return result
    finally:
        db.close()
