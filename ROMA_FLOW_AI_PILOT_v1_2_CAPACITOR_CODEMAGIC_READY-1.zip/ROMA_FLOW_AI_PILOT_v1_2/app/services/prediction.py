from __future__ import annotations
from datetime import date
import pandas as pd
from app.config import DATASET_PATH, MODEL_PATH, FORECAST_FEATURES
from app.services.model_v1 import enrich, train_v1
import joblib


def _ensure_model():
    if not MODEL_PATH.exists():
        train_v1()
    return joblib.load(MODEL_PATH)


def _row_for(asset_id:str, date_value:date, hour:int):
    df=enrich(pd.read_csv(DATASET_PATH))
    ts=pd.Timestamp(date_value)
    asset=df[df.asset_id==asset_id].copy()
    if asset.empty: raise KeyError(asset_id)
    asset['date_distance']=(asset.date_dt-ts).abs().dt.days
    row=asset[(asset.hour==hour)&(asset.dow==ts.dayofweek)]
    if row.empty: row=asset[asset.hour==hour]
    r=row.sort_values('date_distance').iloc[0].copy()
    r['date']=ts.date().isoformat(); r['dow']=ts.dayofweek; r['month']=ts.month; r['is_weekend']=int(ts.dayofweek>=5)
    return r


def forecast(asset_id:str,date_value:date,hour:int):
    bundle=_ensure_model(); row=_row_for(asset_id,date_value,hour)
    x=pd.DataFrame([row])
    X=x[FORECAST_FEATURES].apply(pd.to_numeric,errors='coerce').fillna(0.0)
    pred=float(max(0,bundle['model'].predict(X)[0]))
    capacity=float(row['capacity']); pressure=min(1.0,pred/max(1,capacity))
    label='VERY HIGH' if pressure>=0.95 else 'HIGH' if pressure>=0.85 else 'MEDIUM' if pressure>=0.65 else 'LOW'
    return {'asset_id':asset_id,'date':date_value.isoformat(),'hour':hour,'predicted_demand':round(pred,1),'capacity':int(capacity),'pressure':round(pressure,3),'pressure_label':label,'model_mae':round(bundle['mae'],2),'model_rmse':round(bundle['rmse'],2),'model_version':'forecast-v1'}
