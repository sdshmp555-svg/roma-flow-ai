from __future__ import annotations
from math import radians, sin, cos, sqrt, atan2

# Core optimisation logic is deliberately explicit and interpretable for MVP validation.
# It avoids recommending a destination whose projected pressure would cross the threshold.

PRESSURE_HIGH=0.85
PRESSURE_VERY_HIGH=0.95

def haversine_km(lat1,lon1,lat2,lon2):
    R=6371
    p1,p2=radians(lat1),radians(lat2)
    dp=radians(lat2-lat1); dl=radians(lon2-lon1)
    a=sin(dp/2)**2+cos(p1)*cos(p2)*sin(dl/2)**2
    return 2*R*atan2(sqrt(a),sqrt(1-a))

def candidate_score(*, relief, capacity_availability, relevance, economic_opportunity, accessibility, travel_efficiency, strategic_priority):
    return (
        0.30*relief
        +0.20*capacity_availability
        +0.15*relevance
        +0.15*economic_opportunity
        +0.10*accessibility
        +0.05*travel_efficiency
        +0.05*strategic_priority
    )

def optimise(source, candidates, diversion_share=0.15):
    if source["pressure"] < PRESSURE_HIGH:
        return {"source":source["asset_id"],"action":"monitor","recommendations":[]}
    scored=[]
    source_lat,source_lon=source["lat"],source["lon"]
    for c in candidates:
        if c["asset_id"]==source["asset_id"]:
            continue
        current_pressure=c["pressure"]
        available=max(0.0,1.0-current_pressure)
        if available < 0.15:
            continue
        projected_pressure=min(1.0,current_pressure+diversion_share*0.55*(1.0-available))
        if projected_pressure>=0.90:
            continue
        distance=haversine_km(source_lat,source_lon,c["lat"],c["lon"])
        travel_eff=max(0.0,1-distance/12)
        relief=max(0.0,min(1.0,(source["pressure"]-0.60)/0.40))
        relevance=c.get("relevance",0.7)
        economic=c.get("economic_opportunity",c.get("strategic_priority",0.5))
        score=candidate_score(relief=relief,capacity_availability=available,relevance=relevance,economic_opportunity=economic,accessibility=c.get("accessibility",0.8),travel_efficiency=travel_eff,strategic_priority=c.get("strategic_priority",0.5))
        scored.append({**c,"distance_km":distance,"projected_pressure":projected_pressure,"score":round(score,4)})
    scored.sort(key=lambda x:x["score"],reverse=True)
    return {"source":source["asset_id"],"action":"redistribute","recommendations":scored[:3]}
