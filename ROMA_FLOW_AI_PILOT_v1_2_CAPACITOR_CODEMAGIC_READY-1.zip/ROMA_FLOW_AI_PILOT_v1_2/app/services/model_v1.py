from __future__ import annotations
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
from app.config import DATASET_PATH, MODEL_PATH, FORECAST_FEATURES


def enrich(df: pd.DataFrame) -> pd.DataFrame:
    out=df.copy()
    out['date_dt']=pd.to_datetime(out['date'])
    out=out.sort_values(['asset_id','date_dt','hour']).reset_index(drop=True)
    g=out.groupby('asset_id', group_keys=False)
    out['lag_1h']=g['demand'].shift(1)
    out['lag_24h']=g['demand'].shift(24)
    out['rolling_24h_mean']=g['demand'].shift(1).rolling(24,min_periods=6).mean().reset_index(level=0,drop=True)
    out['rolling_7d_mean']=g['demand'].shift(24).rolling(168,min_periods=24).mean().reset_index(level=0,drop=True)
    x=out['mobility_index'].astype(float)
    out['realtime_delay_sec']=np.clip((75-x)*11,0,900)
    out['nearby_delayed_route_count']=np.clip(np.round((75-x)/12),0,8)
    out['nearby_alert_count']=np.clip(np.round((70-x)/15),0,5)
    out['active_vehicle_count']=np.clip(np.round(6+x/12),3,20)
    out['disruption_score']=np.clip((75-x)/40,0,1)
    out['realtime_access_score']=np.clip(1-out['disruption_score']*0.8,0.2,1.0)
    return out


def _clean(df, cols):
    return df[cols].replace([np.inf,-np.inf],np.nan).fillna(df[cols].median(numeric_only=True) if hasattr(df[cols],'median') else 0).fillna(0)


def train_v1():
    df=enrich(pd.read_csv(DATASET_PATH))
    unique=sorted(df['date_dt'].dt.date.astype(str).unique())
    cutoff=unique[-45]
    train=df[df.date_dt.dt.date.astype(str)<cutoff].copy()
    test=df[df.date_dt.dt.date.astype(str)>=cutoff].copy()
    model=GradientBoostingRegressor(random_state=42,n_estimators=140,max_depth=3,learning_rate=0.04,loss='huber')
    model.fit(_clean(train,FORECAST_FEATURES),train['demand'])
    pred=np.maximum(0,model.predict(_clean(test,FORECAST_FEATURES)))
    mae=float(mean_absolute_error(test['demand'],pred))
    rmse=float(np.sqrt(mean_squared_error(test['demand'],pred)))
    bundle={'model':model,'features':FORECAST_FEATURES,'mae':mae,'rmse':rmse,'train_rows':len(train),'test_rows':len(test),'version':'forecast-v1'}
    MODEL_PATH.parent.mkdir(parents=True,exist_ok=True)
    joblib.dump(bundle,MODEL_PATH)
    report={'version':'forecast-v1','mae':mae,'rmse':rmse,'train_rows':len(train),'test_rows':len(test),'feature_count':len(FORECAST_FEATURES)}
    (DATASET_PATH.parent/'forecast_v1_report.json').write_text(json.dumps(report,indent=2))
    return report
