from __future__ import annotations
import io, zipfile, pandas as pd
from datetime import datetime, timezone
from pathlib import Path
from app.services.geospatial import build_asset_mobility_profile
from app.services.data_generator import ASSETS


def load_static_gtfs_tables(gtfs_dir: Path):
    stops=pd.read_csv(gtfs_dir/"gtfs_stops.csv")
    routes=pd.read_csv(gtfs_dir/"gtfs_routes.csv") if (gtfs_dir/"gtfs_routes.csv").exists() else None
    trips=pd.read_csv(gtfs_dir/"gtfs_trips.csv") if (gtfs_dir/"gtfs_trips.csv").exists() else None
    stop_times=pd.read_csv(gtfs_dir/"gtfs_stop_times.csv") if (gtfs_dir/"gtfs_stop_times.csv").exists() else None
    route_trip = None
    if trips is not None and {"trip_id","route_id"}.issubset(trips.columns):
        route_trip=trips[["trip_id","route_id"]].drop_duplicates()
    return stops, route_trip, stop_times


def compute_asset_mobility(gtfs_dir: Path, assets: list[dict] | None = None, radius_m: float = 700.0):
    assets=assets or ASSETS
    stops, route_trip, stop_times=load_static_gtfs_tables(gtfs_dir)
    profile=build_asset_mobility_profile(assets, stops, stop_times, route_trip, radius_m=radius_m)
    profile["ts"]=datetime.now(timezone.utc).replace(tzinfo=None)
    return profile


def realtime_feed_paths(raw_dir: Path) -> dict:
    return {
      "trip_updates": raw_dir/"rome_rtgtfs_trip_updates_feed.pb",
      "vehicle_positions": raw_dir/"rome_rtgtfs_vehicle_positions_feed.pb",
      "service_alerts": raw_dir/"rome_rtgtfs_service_alerts_feed.pb",
    }
