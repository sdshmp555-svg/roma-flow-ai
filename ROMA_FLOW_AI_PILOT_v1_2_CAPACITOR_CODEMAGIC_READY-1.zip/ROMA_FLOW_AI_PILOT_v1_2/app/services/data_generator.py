from __future__ import annotations
import math
from datetime import datetime, timedelta
from pathlib import Path
import numpy as np
import pandas as pd
from app.config import DATASET_PATH

ASSETS = [
    {"asset_id":"TRV_TREVI","zone_id":"A","name":"Trevi Fountain","asset_type":"landmark","lat":41.9009,"lon":12.4833,"capacity":430,"priority":0.2},
    {"asset_id":"PAN_PANTHEON","zone_id":"A","name":"Pantheon","asset_type":"heritage","lat":41.8986,"lon":12.4768,"capacity":300,"priority":0.3},
    {"asset_id":"BAR_NAVONA","zone_id":"A","name":"Piazza Navona Experience","asset_type":"public_space","lat":41.8992,"lon":12.4731,"capacity":360,"priority":0.35},
    {"asset_id":"MNT_MONTI","zone_id":"B","name":"Monti Heritage Walk","asset_type":"neighbourhood","lat":41.8955,"lon":12.4943,"capacity":260,"priority":0.85},
    {"asset_id":"SMA_MAJORE","zone_id":"B","name":"Santa Maria Maggiore","asset_type":"heritage","lat":41.8976,"lon":12.4988,"capacity":280,"priority":0.65},
    {"asset_id":"ESQ_FOOD","zone_id":"B","name":"Esquilino Food Experience","asset_type":"experience","lat":41.8952,"lon":12.5048,"capacity":75,"priority":0.95},
    {"asset_id":"GHE_JEWISH","zone_id":"C","name":"Jewish Ghetto Walk","asset_type":"neighbourhood","lat":41.8947,"lon":12.4779,"capacity":220,"priority":0.9},
    {"asset_id":"TRS_FOOD","zone_id":"C","name":"Trastevere Food Experience","asset_type":"experience","lat":41.8896,"lon":12.4698,"capacity":95,"priority":1.0},
    {"asset_id":"TRS_SANTA","zone_id":"C","name":"Santa Maria in Trastevere","asset_type":"heritage","lat":41.8892,"lon":12.4691,"capacity":300,"priority":0.8},
    {"asset_id":"MAXXI_SIDE","zone_id":"C","name":"Local Creative District","asset_type":"creative","lat":41.9280,"lon":12.4663,"capacity":180,"priority":0.9},
    {"asset_id":"TERME","zone_id":"B","name":"Baths of Diocletian","asset_type":"heritage","lat":41.9009,"lon":12.4966,"capacity":220,"priority":0.75},
    {"asset_id":"QUIRINAL","zone_id":"A","name":"Quirinal Cultural Route","asset_type":"heritage","lat":41.8993,"lon":12.4862,"capacity":180,"priority":0.78},
    {"asset_id":"TESTACCIO","zone_id":"C","name":"Testaccio Market Experience","asset_type":"experience","lat":41.8797,"lon":12.4710,"capacity":85,"priority":0.92},
    {"asset_id":"CELIO","zone_id":"A","name":"Celio Archaeological Walk","asset_type":"heritage","lat":41.8856,"lon":12.4930,"capacity":170,"priority":0.88},
    {"asset_id":"APPIA","zone_id":"C","name":"Appian Way Urban Escape","asset_type":"experience","lat":41.8530,"lon":12.5120,"capacity":110,"priority":0.98},
]

def _seasonal(hour: int) -> float:
    return max(0, math.sin((hour - 8) / 24 * 2 * math.pi))

def _asset_base(asset_type: str) -> float:
    return {"landmark":220, "heritage":155, "public_space":180, "neighbourhood":95, "experience":60, "creative":55}.get(asset_type, 80)

def generate_history(start="2025-09-01", days=365, seed=42):
    rng=np.random.default_rng(seed)
    start_dt=datetime.fromisoformat(start)
    records=[]
    holidays={(1,1),(4,25),(5,1),(6,2),(8,15),(12,8),(12,25),(12,26)}
    for d in range(days):
        day=start_dt+timedelta(days=d)
        dow=day.weekday()
        for hour in range(8,23):
            rain = max(0, rng.normal(0.7 if dow < 5 else 0.9, 1.6))
            temp = 15 + 10*math.sin((day.timetuple().tm_yday)/365*2*math.pi) + rng.normal(0,2)
            is_holiday=int((day.month, day.day) in holidays)
            event=int((d % 47 == 0) or (d % 71 == 0 and hour in (18,19,20)))
            mobility=65 + 10*(_seasonal(hour)) + 6*(dow>=4) - 15*(rain>3) + rng.normal(0,4)
            mobility=max(20,min(100,mobility))
            weekend=int(dow>=5)
            for a in ASSETS:
                base=_asset_base(a["asset_type"])
                peak = 1.0 + 0.45*_seasonal(hour)
                weekend_mult = 1.15 if weekend else 1.0
                holiday_mult = 1.18 if is_holiday else 1.0
                rain_mult = 0.72 if rain>5 and a["asset_type"] in ("public_space","neighbourhood","experience") else 0.92 if rain>5 else 1.0
                event_mult = 1.28 if event else 1.0
                hotspot_mult = 1.65 if a["asset_id"]=="TRV_TREVI" and hour in (16,17,18,19) else 1.0
                lowuse_boost = 1.15 if a["priority"]>0.85 and hour in (17,18,19) else 1.0
                demand=base*peak*weekend_mult*holiday_mult*rain_mult*event_mult*hotspot_mult*lowuse_boost
                demand += 0.18*mobility*base/100
                demand += rng.normal(0, max(5,demand*0.07))
                demand=int(max(5, demand))
                capacity=int(a["capacity"])
                records.append({"date":day.date().isoformat(),"hour":hour,"asset_id":a["asset_id"],"demand":demand,"capacity":capacity,"dow":dow,"month":day.month,"is_weekend":weekend,"is_holiday":is_holiday,"rain_mm":round(rain,2),"temperature_c":round(temp,2),"major_event":event,"mobility_index":round(mobility,2)})
    df=pd.DataFrame(records)
    df["historical_demand_7d"]=df.groupby("asset_id")["demand"].transform(lambda s:s.shift(24*7).fillna(s.rolling(24).mean()))
    df["historical_demand_28d"]=df.groupby("asset_id")["demand"].transform(lambda s:s.shift(24*28).fillna(s.rolling(24*7,min_periods=24).mean()))
    DATASET_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(DATASET_PATH,index=False)
    return df
