from __future__ import annotations
from math import radians, sin, cos, sqrt, atan2
import pandas as pd

EARTH_RADIUS_M = 6_371_000.0

def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = radians(lat1), radians(lat2)
    dlat = radians(lat2-lat1)
    dlon = radians(lon2-lon1)
    a = sin(dlat/2)**2 + cos(p1)*cos(p2)*sin(dlon/2)**2
    return 2*EARTH_RADIUS_M*atan2(sqrt(a), sqrt(max(0.0,1-a)))

def build_asset_mobility_profile(assets: list[dict], stops: pd.DataFrame, stop_times: pd.DataFrame | None = None,
                                 routes: pd.DataFrame | None = None, radius_m: float = 700.0) -> pd.DataFrame:
    required = {"stop_lat", "stop_lon"}
    missing = required - set(stops.columns)
    if missing:
        raise ValueError(f"stops missing required columns: {sorted(missing)}")
    stops = stops.copy()
    stops["stop_lat"] = pd.to_numeric(stops["stop_lat"], errors="coerce")
    stops["stop_lon"] = pd.to_numeric(stops["stop_lon"], errors="coerce")
    stops = stops.dropna(subset=["stop_lat", "stop_lon"])

    route_by_stop = {}
    if stop_times is not None and routes is not None and "stop_id" in stop_times.columns and "trip_id" in stop_times.columns and "trip_id" in routes.columns:
        # routes usually does not contain trip_id, so this branch is only used when a pre-joined table is provided.
        pass

    # Standard GTFS route density: stop -> distinct route IDs via trip->route and stop_times.
    route_count_by_stop = pd.Series(dtype=float)
    if stop_times is not None and {"stop_id", "trip_id"}.issubset(stop_times.columns):
        trips = None
        if routes is not None and {"trip_id", "route_id"}.issubset(routes.columns):
            trips = routes[["trip_id", "route_id"]].drop_duplicates()
        if trips is not None:
            joined = stop_times[["stop_id", "trip_id"]].drop_duplicates().merge(trips, on="trip_id", how="left")
            route_count_by_stop = joined.groupby("stop_id")["route_id"].nunique()
        else:
            route_count_by_stop = stop_times.groupby("stop_id")["trip_id"].nunique()

    rows=[]
    for asset in assets:
        nearby = []
        min_dist = float("inf")
        for _, s in stops.iterrows():
            d=haversine_m(asset["lat"], asset["lon"], float(s.stop_lat), float(s.stop_lon))
            if d < min_dist:
                min_dist=d
            if d <= radius_m:
                sid=s.get("stop_id")
                nearby.append(sid)
        nearby_stops=len(set(x for x in nearby if pd.notna(x)))
        nearby_routes=int(sum(float(route_count_by_stop.get(sid, 0)) for sid in set(nearby) if sid in route_count_by_stop.index))
        stop_factor=min(1.0, nearby_stops/8.0)
        route_factor=min(1.0, nearby_routes/20.0)
        distance_factor=max(0.0, 1.0-min_dist/1200.0) if min_dist!=float("inf") else 0.0
        access=(0.45*stop_factor+0.40*route_factor+0.15*distance_factor)
        rows.append({"asset_id":asset["asset_id"],"nearby_stops":nearby_stops,"nearby_routes":nearby_routes,
                     "nearest_stop_m":round(min_dist if min_dist!=float("inf") else 99999.0,1),
                     "mobility_access_score":round(access,4)})
    return pd.DataFrame(rows)
