from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

BASE_FEATURES = [
    'hour','dow','month','is_weekend','is_holiday','rain_mm','temperature_c',
    'major_event','capacity','historical_demand_7d','historical_demand_28d'
]
REALTIME_FEATURES = [
    'mobility_index','realtime_delay_sec','nearby_delayed_route_count',
    'nearby_alert_count','active_vehicle_count','disruption_score','realtime_access_score'
]

@dataclass
class CalibrationResult:
    baseline_mae: float
    enhanced_mae: float
    baseline_rmse: float
    enhanced_rmse: float
    mae_improvement_pct: float
    rmse_improvement_pct: float
    train_rows: int
    test_rows: int
    realtime_features: list[str]
    note: str = 'Synthetic calibration; replace realtime feature columns with live feature store snapshots before pilot.'


def _add_temporal_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out['date_dt'] = pd.to_datetime(out['date'])
    out = out.sort_values(['asset_id','date_dt','hour']).reset_index(drop=True)
    g = out.groupby('asset_id', group_keys=False)
    out['lag_1h'] = g['demand'].shift(1)
    out['lag_24h'] = g['demand'].shift(24)
    out['rolling_24h_mean'] = g['demand'].shift(1).rolling(24, min_periods=6).mean().reset_index(level=0, drop=True)
    out['rolling_7d_mean'] = g['demand'].shift(24).rolling(24*7, min_periods=24).mean().reset_index(level=0, drop=True)
    return out


def _add_realtime_proxy_features(df: pd.DataFrame) -> pd.DataFrame:
    """Create clearly-labelled calibration proxies from the synthetic mobility signal.
    These are not presented as live Rome data; they emulate the feature-store contract.
    """
    out = df.copy()
    x = out['mobility_index'].astype(float)
    out['realtime_delay_sec'] = np.clip((75.0 - x) * 11.0, 0, 900)
    out['nearby_delayed_route_count'] = np.clip(np.round((75.0 - x) / 12.0), 0, 8)
    out['nearby_alert_count'] = np.clip(np.round((70.0 - x) / 15.0), 0, 5)
    out['active_vehicle_count'] = np.clip(np.round(6 + x / 12.0), 3, 20)
    out['disruption_score'] = np.clip((75.0 - x) / 40.0, 0, 1)
    out['realtime_access_score'] = np.clip(1.0 - out['disruption_score'] * 0.8, 0.2, 1.0)
    return out


def _clean_features(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    x = df[cols].copy()
    for c in cols:
        x[c] = pd.to_numeric(x[c], errors='coerce')
    return x.replace([np.inf, -np.inf], np.nan).fillna(0.0)


def calibrate(dataset_path: Path, output_path: Path) -> dict:
    df = pd.read_csv(dataset_path)
    df = _add_temporal_features(df)
    df = _add_realtime_proxy_features(df)
    df = df.sort_values(['date_dt','hour','asset_id']).reset_index(drop=True)
    unique_dates = sorted(df['date_dt'].dt.date.astype(str).unique())
    cutoff = unique_dates[-30]
    train = df[df['date_dt'].dt.date.astype(str) < cutoff].copy()
    test = df[df['date_dt'].dt.date.astype(str) >= cutoff].copy()
    train = train.dropna(subset=['demand'])
    test = test.dropna(subset=['demand'])

    baseline_features = BASE_FEATURES + ['lag_1h','lag_24h','rolling_24h_mean','rolling_7d_mean']
    enhanced_features = baseline_features + REALTIME_FEATURES

    baseline = GradientBoostingRegressor(random_state=42, n_estimators=80, max_depth=2, learning_rate=0.05, loss='huber')
    enhanced = GradientBoostingRegressor(random_state=42, n_estimators=80, max_depth=2, learning_rate=0.05, loss='huber')
    baseline.fit(_clean_features(train, baseline_features), train['demand'])
    enhanced.fit(_clean_features(train, enhanced_features), train['demand'])
    y = test['demand'].to_numpy()
    p0 = np.maximum(0, baseline.predict(_clean_features(test, baseline_features)))
    p1 = np.maximum(0, enhanced.predict(_clean_features(test, enhanced_features)))
    b_mae = float(mean_absolute_error(y, p0)); e_mae = float(mean_absolute_error(y, p1))
    b_rmse = float(np.sqrt(mean_squared_error(y, p0))); e_rmse = float(np.sqrt(mean_squared_error(y, p1)))
    result = CalibrationResult(
        baseline_mae=b_mae, enhanced_mae=e_mae, baseline_rmse=b_rmse, enhanced_rmse=e_rmse,
        mae_improvement_pct=float((b_mae-e_mae)/b_mae*100) if b_mae else 0.0,
        rmse_improvement_pct=float((b_rmse-e_rmse)/b_rmse*100) if b_rmse else 0.0,
        train_rows=len(train), test_rows=len(test), realtime_features=REALTIME_FEATURES
    )
    payload = asdict(result)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2))
    return payload
