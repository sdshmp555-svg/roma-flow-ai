from __future__ import annotations
from datetime import datetime, UTC
from sqlalchemy import select, delete
from app.db import SessionLocal
from app.models.domain import Asset, KnowledgeEdge
from app.models.mobility import MobilityAssetSnapshot


def seed_knowledge_graph():
    db=SessionLocal()
    try:
        db.execute(delete(KnowledgeEdge))
        assets=db.scalars(select(Asset).where(Asset.active==True)).all()
        edges=[]
        for a in assets:
            for b in assets:
                if a.id==b.id: continue
                if a.zone_id==b.zone_id:
                    edges.append(KnowledgeEdge(source_id=a.id,target_id=b.id,relation="same_zone",weight=1.0))
                if a.asset_type==b.asset_type:
                    edges.append(KnowledgeEdge(source_id=a.id,target_id=b.id,relation="same_type",weight=0.5))
        db.add_all(edges)
        db.commit()
        return {"edges_created":len(edges),"assets":len(assets),"generated_at":datetime.now(UTC).isoformat()}
    finally:
        db.close()


def graph_for_asset(asset_id:str):
    db=SessionLocal()
    try:
        edges=db.scalars(select(KnowledgeEdge).where(KnowledgeEdge.source_id==asset_id)).all()
        return [{"source_id":e.source_id,"target_id":e.target_id,"relation":e.relation,"weight":e.weight} for e in edges]
    finally:
        db.close()
