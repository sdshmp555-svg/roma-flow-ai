from __future__ import annotations
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error
from app.config import FEATURES, DATASET_PATH, MODEL_PATH

TARGET="demand"

def train_model():
    df=pd.read_csv(DATASET_PATH)
    df=df.sort_values(["date","hour","asset_id"])
    df["historical_demand_7d"]=df["historical_demand_7d"].fillna(df["historical_demand_7d"].median())
    df["historical_demand_28d"]=df["historical_demand_28d"].fillna(df["historical_demand_28d"].median())
    # Hold out the latest 30 days to simulate forward prediction.
    unique_dates=sorted(df["date"].unique())
    cutoff=unique_dates[-30]
    train=df[df["date"]<cutoff]
    test=df[df["date"]>=cutoff]
    model=GradientBoostingRegressor(random_state=42, n_estimators=180, max_depth=3, learning_rate=0.05, loss="huber")
    model.fit(train[FEATURES],train[TARGET])
    pred=np.maximum(0,model.predict(test[FEATURES]))
    mae=float(mean_absolute_error(test[TARGET],pred))
    joblib.dump({"model":model,"mae":mae,"features":FEATURES},MODEL_PATH)
    return {"mae":mae,"train_rows":len(train),"test_rows":len(test)}

def load_model():
    return joblib.load(MODEL_PATH)
