from app.config import *

def readiness():
    return {
      "application":"ROMA FLOW AI",
      "version":"1.2.0-pilot-ready",
      "database":"SQLite default; PostgreSQL/PostGIS schema included",
      "real_connectors":["Roma Mobilita GTFS","Roma Mobilita GTFS-Realtime","Open-Meteo"],
      "live_fetch_requires_network":True,
      "production_controls":["env-config","health endpoint","structured ingestion registry","data provenance","privacy-by-default design","Dockerfile","security checklist"],
      "mobile":"responsive web dashboard now; native/PWA packaging is a subsequent stage"
    }
