from __future__ import annotations
from datetime import date
from app.services.prediction import forecast
from app.services.recommendation import build_recommendations


def simulate_intervention(source_id:str,date_value:date,hour:int,diversion:int=20):
    before=forecast(source_id,date_value,hour)
    rec=build_recommendations(source_id,date_value,hour,diversion_share=min(0.3,max(0.05,diversion/100)))
    results=[]
    for r in rec.get("recommendations",[])[:3]:
        projected_before=r["projected_pressure"]
        relief=min(0.20, diversion/100*0.6)
        projected_after=max(0.0, projected_before)
        results.append({**r,"diverted_visitors":diversion,"estimated_source_relief":round(relief,3),"estimated_target_pressure":round(projected_after,3)})
    source_after=max(0.0,before["pressure"]-min(0.25,diversion/100))
    return {"baseline":before,"recommendations":results,"estimated_after_source_pressure":round(source_after,3),"note":"Impact estimates are decision-support simulations, not measured pilot outcomes."}
