from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
from app.ingestion.realtime import download_feed, URLS
from app.ingestion.gtfs_rt_decode import decode_feed, summarise_realtime


def ingest_and_summarise(kind: str, raw_dir: Path) -> dict:
    result = download_feed(kind, raw_dir)
    if result.get('status') != 'ok':
        return result
    payload = Path(result['artifact']).read_bytes()
    decoded = decode_feed(payload, kind)
    summary = summarise_realtime(decoded, kind)
    return {**result, 'summary': summary, 'header': decoded.get('header', {})}

# Backwards-compatible helper used by the spatial feature-store stage.
def latest_feed_paths(raw_dir: Path) -> dict:
    return {
        'trip_updates': raw_dir/'rome_rtgtfs_trip_updates_feed.pb',
        'vehicle_positions': raw_dir/'rome_rtgtfs_vehicle_positions_feed.pb',
        'service_alerts': raw_dir/'rome_rtgtfs_service_alerts_feed.pb',
    }
