from __future__ import annotations
from datetime import datetime, UTC
from sqlalchemy import select
from app.db import SessionLocal
from app.models.domain import Asset, CapacitySnapshot


def seed_capacity(ts=None):
    ts=ts or datetime.now(UTC)
    db=SessionLocal()
    try:
        for a in db.scalars(select(Asset).where(Asset.active==True)).all():
            # Deterministic starting occupancy for demo; partner feeds replace this later.
            booked=int(round(a.nominal_capacity * (0.25 if a.strategic_priority>=0.8 else 0.55)))
            available=max(0,a.nominal_capacity-booked)
            price={"experience":39.0,"neighbourhood":25.0,"heritage":18.0,"landmark":0.0,"public_space":0.0,"creative":20.0}.get(a.asset_type,20.0)
            db.add(CapacitySnapshot(asset_id=a.id,ts=ts,capacity=a.nominal_capacity,booked=booked,available=available,price_eur=price,source="seed_demo"))
        db.commit()
        return {"status":"ok","timestamp":ts.isoformat()}
    finally:
        db.close()


def capacity_map(ts=None):
    db=SessionLocal()
    try:
        rows=db.scalars(select(CapacitySnapshot).order_by(CapacitySnapshot.id.desc())).all()
        latest={}
        for r in rows:
            latest.setdefault(r.asset_id,r)
        return {k:{"capacity":v.capacity,"booked":v.booked,"available":v.available,"occupancy":round(v.booked/max(1,v.capacity),3),"price_eur":v.price_eur,"source":v.source,"ts":v.ts.isoformat()} for k,v in latest.items()}
    finally:
        db.close()
