from __future__ import annotations
from math import radians, sin, cos, sqrt, atan2
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

from app.services.data_generator import ASSETS
from app.ingestion.gtfs_rt_decode import decode_feed


def haversine_m(lat1, lon1, lat2, lon2):
    R = 6371000.0
    p1, p2 = radians(lat1), radians(lat2)
    dp = radians(lat2-lat1); dl = radians(lon2-lon1)
    a = sin(dp/2)**2 + cos(p1)*cos(p2)*sin(dl/2)**2
    return 2*R*atan2(sqrt(a), sqrt(1-a))


def nearest_stop(lat, lon, stops: pd.DataFrame):
    best = None
    best_d = None
    for r in stops.itertuples(index=False):
        d = haversine_m(lat, lon, float(r.stop_lat), float(r.stop_lon))
        if best_d is None or d < best_d:
            best_d = d; best = str(r.stop_id)
    return best, float(best_d or 999999.0)


def parse_feed_file(path: Path, kind: str):
    if not path.exists():
        return {'header': {}, 'entity_count': 0, 'entities': []}
    return decode_feed(path.read_bytes(), kind)


def build_spatial_realtime_features(gtfs_dir: Path, realtime_dir: Path, assets: list[dict] | None = None, radius_m: float = 800.0):
    assets = assets or ASSETS
    stops = pd.read_csv(gtfs_dir / 'gtfs_stops.csv')
    routes = pd.read_csv(gtfs_dir / 'gtfs_routes.csv') if (gtfs_dir/'gtfs_routes.csv').exists() else pd.DataFrame()

    trip = parse_feed_file(realtime_dir/'rome_rtgtfs_trip_updates_feed.pb', 'trip_updates')
    vehicles = parse_feed_file(realtime_dir/'rome_rtgtfs_vehicle_positions_feed.pb', 'vehicle_positions')
    alerts = parse_feed_file(realtime_dir/'rome_rtgtfs_service_alerts_feed.pb', 'service_alerts')

    delayed_by_route: dict[str, list[float]] = {}
    delayed_by_stop: dict[str, list[float]] = {}
    for e in trip.get('entities', []):
        tu = e.get('trip_update', {})
        rid = (tu.get('trip') or {}).get('route_id')
        vals=[]
        if tu.get('delay') is not None: vals.append(float(tu['delay']))
        for stu in tu.get('stop_time_updates', []):
            if stu.get('stop_id') and any(k in stu for k in ('arrival','departure')):
                evt = stu.get('arrival') or stu.get('departure') or {}
                if evt.get('delay') is not None:
                    d=float(evt['delay']); vals.append(d); delayed_by_stop.setdefault(stu['stop_id'], []).append(d)
        if rid and vals:
            delayed_by_route.setdefault(rid, []).extend(vals)

    alert_routes=set(); alert_stops=set(); alert_count=0
    for e in alerts.get('entities', []):
        a=e.get('alert', {})
        if not a: continue
        alert_count += 1
        for ent in a.get('informed_entities', []):
            if ent.get('route_id'): alert_routes.add(ent['route_id'])
            if ent.get('stop_id'): alert_stops.add(ent['stop_id'])

    vehicle_count=0; positioned=[]
    for e in vehicles.get('entities', []):
        v=e.get('vehicle', {})
        p=v.get('position') or {}
        vehicle_count += 1
        if p.get('latitude') is not None and p.get('longitude') is not None:
            positioned.append(v)

    ts = datetime.now(timezone.utc).replace(tzinfo=None)
    rows=[]
    for a in assets:
        nearby = []
        for s in stops.itertuples(index=False):
            d=haversine_m(a['lat'], a['lon'], float(s.stop_lat), float(s.stop_lon))
            if d <= radius_m: nearby.append((s,d))
        nearest_id, nearest_d = nearest_stop(a['lat'], a['lon'], stops)
        nearby_stop_ids={str(s.stop_id) for s,_ in nearby}
        nearby_routes=set()
        if not routes.empty and 'route_id' in routes.columns:
            # route coverage is intentionally approximate at this stage; realtime route IDs are used where available.
            nearby_routes = {r for r in delayed_by_route if delayed_by_route.get(r)}
        route_delays=[d for rid, vals in delayed_by_route.items() if vals for d in [sum(vals)/len(vals)] ]
        nearby_delayed_route_count=len([rid for rid in delayed_by_route if rid in nearby_routes])
        local_delays=[]
        for sid in nearby_stop_ids:
            local_delays.extend(delayed_by_stop.get(sid, []))
        avg_delay=sum(local_delays)/len(local_delays) if local_delays else (sum(route_delays)/len(route_delays) if route_delays else 0.0)
        local_alerts=len(nearby_stop_ids & alert_stops)
        local_route_alerts=len(nearby_routes & alert_routes)
        nearby_alert_count=local_alerts+local_route_alerts
        delay_component=min(1.0, avg_delay/600.0)
        alert_component=min(1.0, nearby_alert_count/5.0)
        disruption=min(1.0, 0.65*delay_component+0.35*alert_component)
        access=max(0.0, 1.0-disruption)
        rows.append({
            'ts': ts, 'asset_id': a['asset_id'], 'nearest_stop_id': nearest_id,
            'nearby_stop_count': len(nearby), 'nearby_route_count': len(nearby_routes),
            'realtime_delay_sec': round(avg_delay,2), 'affected_route_count': len(alert_routes),
            'affected_stop_count': len(alert_stops), 'service_alert_count': alert_count,
            'active_vehicle_count': vehicle_count, 'nearby_delayed_route_count': nearby_delayed_route_count,
            'nearby_alert_count': nearby_alert_count, 'realtime_access_score': round(access,4),
            'disruption_score': round(disruption,4)
        })
    return pd.DataFrame(rows)
