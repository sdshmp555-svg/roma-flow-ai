from datetime import datetime
from sqlalchemy import DateTime, Float, Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base

class MobilityAssetSnapshot(Base):
    __tablename__ = "mobility_asset_snapshots"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    asset_id: Mapped[str] = mapped_column(String, index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    nearby_stops: Mapped[int] = mapped_column(Integer)
    nearby_routes: Mapped[int] = mapped_column(Integer)
    service_events: Mapped[int] = mapped_column(Integer, default=0)
    nearest_stop_m: Mapped[float] = mapped_column(Float)
    mobility_access_score: Mapped[float] = mapped_column(Float)

class RealtimeMobilitySnapshot(Base):
    __tablename__ = "realtime_mobility_snapshots"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kind: Mapped[str] = mapped_column(String, index=True)
    retrieved_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    entity_count: Mapped[int] = mapped_column(Integer, default=0)
    avg_delay_sec: Mapped[float] = mapped_column(Float, default=0.0)
    max_delay_sec: Mapped[float] = mapped_column(Float, default=0.0)
    routes_affected: Mapped[int] = mapped_column(Integer, default=0)
    stops_affected: Mapped[int] = mapped_column(Integer, default=0)
    positioned_vehicles: Mapped[int] = mapped_column(Integer, default=0)
    vehicles: Mapped[int] = mapped_column(Integer, default=0)
    alerts: Mapped[int] = mapped_column(Integer, default=0)
