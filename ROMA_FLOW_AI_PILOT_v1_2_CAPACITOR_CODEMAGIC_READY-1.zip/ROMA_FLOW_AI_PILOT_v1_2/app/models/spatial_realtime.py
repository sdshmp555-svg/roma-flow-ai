from datetime import datetime
from sqlalchemy import DateTime, Float, Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base

class SpatialRealtimeFeature(Base):
    __tablename__ = 'spatial_realtime_features'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    asset_id: Mapped[str] = mapped_column(String, index=True)
    nearest_stop_id: Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    nearby_stop_count: Mapped[int] = mapped_column(Integer, default=0)
    nearby_route_count: Mapped[int] = mapped_column(Integer, default=0)
    realtime_delay_sec: Mapped[float] = mapped_column(Float, default=0.0)
    affected_route_count: Mapped[int] = mapped_column(Integer, default=0)
    affected_stop_count: Mapped[int] = mapped_column(Integer, default=0)
    service_alert_count: Mapped[int] = mapped_column(Integer, default=0)
    active_vehicle_count: Mapped[int] = mapped_column(Integer, default=0)
    nearby_delayed_route_count: Mapped[int] = mapped_column(Integer, default=0)
    nearby_alert_count: Mapped[int] = mapped_column(Integer, default=0)
    realtime_access_score: Mapped[float] = mapped_column(Float, default=1.0)
    disruption_score: Mapped[float] = mapped_column(Float, default=0.0)
