from app.models.mobility import MobilityAssetSnapshot
