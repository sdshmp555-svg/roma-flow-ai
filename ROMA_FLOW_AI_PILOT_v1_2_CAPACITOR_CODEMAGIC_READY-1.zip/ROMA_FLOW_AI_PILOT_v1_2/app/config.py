from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
DB_PATH = Path(os.getenv("ROMA_FLOW_DB", DATA_DIR / "roma_flow.db"))
MODEL_PATH = DATA_DIR / "forecast_v1.joblib"
DATASET_PATH = DATA_DIR / "tourism_timeseries.csv"
STATIC_DIR = BASE_DIR / "web"

CITY_LAT = float(os.getenv("ROMA_FLOW_CITY_LAT", "41.9028"))
CITY_LON = float(os.getenv("ROMA_FLOW_CITY_LON", "12.4964"))

ROMA_STATIC_GTFS_URL = os.getenv("ROMA_STATIC_GTFS_URL", "https://romamobilita.it/sites/default/files/rome_static_gtfs.zip")
ROMA_RT_VEHICLES_URL = os.getenv("ROMA_RT_VEHICLES_URL", "https://romamobilita.it/sites/default/files/rome_rtgtfs_vehicle_positions_feed.pb")
ROMA_RT_TRIPS_URL = os.getenv("ROMA_RT_TRIPS_URL", "https://romamobilita.it/sites/default/files/rome_rtgtfs_trip_updates_feed.pb")
ROMA_RT_ALERTS_URL = os.getenv("ROMA_RT_ALERTS_URL", "https://romamobilita.it/sites/default/files/rome_rtgtfs_service_alerts_feed.pb")
OPEN_METEO_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
OPEN_METEO_HISTORICAL_URL = "https://archive-api.open-meteo.com/v1/archive"

FORECAST_FEATURES = [
    "hour","dow","month","is_weekend","is_holiday","rain_mm","temperature_c",
    "major_event","mobility_index","capacity","historical_demand_7d","historical_demand_28d",
    "lag_1h","lag_24h","rolling_24h_mean","rolling_7d_mean",
    "realtime_delay_sec","nearby_delayed_route_count","nearby_alert_count",
    "active_vehicle_count","disruption_score","realtime_access_score",
]
