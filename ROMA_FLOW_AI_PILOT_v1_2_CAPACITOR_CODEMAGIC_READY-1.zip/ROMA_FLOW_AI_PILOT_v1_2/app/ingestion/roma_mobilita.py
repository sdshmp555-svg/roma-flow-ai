from __future__ import annotations
import hashlib
import io
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List

import pandas as pd
import httpx

ROMA_STATIC_GTFS_URL = "https://romamobilita.it/sites/default/files/rome_static_gtfs.zip"
ROMA_STATIC_GTFS_MD5_URL = ROMA_STATIC_GTFS_URL + ".md5"
ROMA_RT_VEHICLE_POSITIONS_URL = "https://romamobilita.it/sites/default/files/rome_rtgtfs_vehicle_positions_feed.pb"
ROMA_RT_TRIP_UPDATES_URL = "https://romamobilita.it/sites/default/files/rome_rtgtfs_trip_updates_feed.pb"
ROMA_RT_ALERTS_URL = "https://romamobilita.it/sites/default/files/rome_rtgtfs_service_alerts_feed.pb"

@dataclass
class ConnectorResult:
    source: str
    retrieved_at: str
    status: str
    bytes_downloaded: int = 0
    checksum_sha256: str | None = None
    error: str | None = None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def download_bytes(url: str, timeout: float = 30.0) -> bytes:
    with httpx.Client(timeout=timeout, follow_redirects=True, headers={"User-Agent": "ROMA-FLOW-AI/0.2"}) as client:
        r = client.get(url)
        r.raise_for_status()
        return r.content


def fetch_static_gtfs(url: str = ROMA_STATIC_GTFS_URL) -> tuple[bytes, ConnectorResult]:
    try:
        payload = download_bytes(url)
        digest = hashlib.sha256(payload).hexdigest()
        return payload, ConnectorResult("roma_mobilita_gtfs_static", _utc_now(), "ok", len(payload), digest)
    except Exception as exc:
        return b"", ConnectorResult("roma_mobilita_gtfs_static", _utc_now(), "error", error=str(exc))


def parse_gtfs_static(payload: bytes) -> Dict[str, pd.DataFrame]:
    required = {"stops.txt", "routes.txt", "trips.txt"}
    with zipfile.ZipFile(io.BytesIO(payload)) as zf:
        names = set(zf.namelist())
        missing = required - names
        if missing:
            raise ValueError(f"GTFS missing required files: {sorted(missing)}")
        result: Dict[str, pd.DataFrame] = {}
        for name in ["stops.txt", "routes.txt", "trips.txt", "stop_times.txt"]:
            if name in names:
                with zf.open(name) as fh:
                    result[name[:-4]] = pd.read_csv(fh, low_memory=False)
    return result


def summarise_gtfs(tables: Dict[str, pd.DataFrame]) -> dict:
    stops = tables["stops"]
    routes = tables["routes"]
    trips = tables["trips"]
    out = {
        "stops": int(len(stops)),
        "routes": int(len(routes)),
        "trips": int(len(trips)),
    }
    if "stop_times" in tables:
        out["stop_time_rows"] = int(len(tables["stop_times"]))
    if "stop_lat" in stops.columns:
        out["bbox"] = {
            "min_lat": float(stops["stop_lat"].min()),
            "max_lat": float(stops["stop_lat"].max()),
            "min_lon": float(stops["stop_lon"].min()),
            "max_lon": float(stops["stop_lon"].max()),
        }
    return out


def ingest_static_gtfs(out_dir: Path, url: str = ROMA_STATIC_GTFS_URL) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    payload, meta = fetch_static_gtfs(url)
    if meta.status != "ok":
        return meta.__dict__
    zip_path = out_dir / "rome_static_gtfs.zip"
    zip_path.write_bytes(payload)
    tables = parse_gtfs_static(payload)
    for key, frame in tables.items():
        frame.to_csv(out_dir / f"gtfs_{key}.csv", index=False)
    meta.status = "ok"
    result = meta.__dict__.copy()
    result["summary"] = summarise_gtfs(tables)
    result["artifact"] = str(zip_path)
    return result
