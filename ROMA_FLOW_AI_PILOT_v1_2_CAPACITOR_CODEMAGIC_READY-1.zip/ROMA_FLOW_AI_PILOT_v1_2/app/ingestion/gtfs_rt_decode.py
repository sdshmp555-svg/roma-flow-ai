from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

# Minimal GTFS-Realtime wire decoder for the fields ROMA FLOW needs in MVP.
# It avoids a runtime dependency on generated protobuf bindings while remaining
# compatible with standard GTFS-Realtime binary feeds.


def _read_varint(buf: bytes, i: int) -> tuple[int, int]:
    shift = 0
    value = 0
    while i < len(buf):
        b = buf[i]
        i += 1
        value |= (b & 0x7F) << shift
        if not (b & 0x80):
            return value, i
        shift += 7
        if shift > 63:
            raise ValueError("invalid varint")
    raise ValueError("truncated varint")


def _read_field(buf: bytes, i: int):
    key, i = _read_varint(buf, i)
    field_no = key >> 3
    wire_type = key & 0x7
    if wire_type == 0:
        val, i = _read_varint(buf, i)
        return field_no, wire_type, val, i
    if wire_type == 1:
        if i + 8 > len(buf):
            raise ValueError("truncated fixed64")
        return field_no, wire_type, buf[i:i+8], i + 8
    if wire_type == 2:
        n, i = _read_varint(buf, i)
        end = i + n
        if end > len(buf):
            raise ValueError("truncated length-delimited field")
        return field_no, wire_type, buf[i:end], end
    if wire_type == 5:
        if i + 4 > len(buf):
            raise ValueError("truncated fixed32")
        return field_no, wire_type, buf[i:i+4], i + 4
    raise ValueError(f"unsupported wire type {wire_type}")


def _fields(buf: bytes):
    i = 0
    while i < len(buf):
        field_no, wire_type, value, i = _read_field(buf, i)
        yield field_no, wire_type, value, i


def _str(b: bytes | None) -> str | None:
    return b.decode("utf-8", errors="replace") if b is not None else None


def _decode_header(data: bytes) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for n, wt, v, _ in _fields(data):
        if n == 1 and wt == 2:
            out["gtfs_realtime_version"] = _str(v)
        elif n == 2 and wt == 0:
            out["incrementality"] = int(v)
        elif n == 3 and wt == 0:
            out["timestamp"] = int(v)
    return out


def _decode_trip_descriptor(data: bytes) -> dict[str, Any]:
    out = {}
    for n, wt, v, _ in _fields(data):
        if n == 1 and wt == 2: out["trip_id"] = _str(v)
        elif n == 2 and wt == 2: out["route_id"] = _str(v)
        elif n == 3 and wt == 2: out["direction_id"] = _str(v)
        elif n == 4 and wt == 2: out["start_time"] = _str(v)
        elif n == 5 and wt == 2: out["start_date"] = _str(v)
        elif n == 6 and wt == 0: out["schedule_relationship"] = int(v)
    return out


def _decode_vehicle_descriptor(data: bytes) -> dict[str, Any]:
    out = {}
    for n, wt, v, _ in _fields(data):
        if n == 1 and wt == 2: out["id"] = _str(v)
        elif n == 2 and wt == 2: out["label"] = _str(v)
        elif n == 3 and wt == 2: out["license_plate"] = _str(v)
    return out


def _decode_position(data: bytes) -> dict[str, Any]:
    import struct
    out = {}
    for n, wt, v, _ in _fields(data):
        if n in (1, 2, 3, 4) and wt == 5:
            x = struct.unpack('<f', v)[0]
            out[{1:'latitude',2:'longitude',3:'bearing',4:'odometer'}[n]] = float(x)
        elif n == 5 and wt == 2:
            import struct
            out['speed'] = float(struct.unpack('<f', v)[0])
    return out


def _decode_stop_time_event(data: bytes) -> dict[str, Any]:
    out = {}
    for n, wt, v, _ in _fields(data):
        if n == 1 and wt == 0: out['delay'] = int(v)
        elif n == 2 and wt == 0: out['time'] = int(v)
        elif n == 3 and wt == 0: out['uncertainty'] = int(v)
    return out


def _decode_stop_time_update(data: bytes) -> dict[str, Any]:
    out = {}
    for n, wt, v, _ in _fields(data):
        if n == 1 and wt == 0: out['stop_sequence'] = int(v)
        elif n == 2 and wt == 2: out['arrival'] = _decode_stop_time_event(v)
        elif n == 3 and wt == 2: out['departure'] = _decode_stop_time_event(v)
        elif n == 4 and wt == 2: out['stop_id'] = _str(v)
        elif n == 5 and wt == 0: out['schedule_relationship'] = int(v)
    return out


def _decode_trip_update(data: bytes) -> dict[str, Any]:
    out: dict[str, Any] = {'stop_time_updates': []}
    for n, wt, v, _ in _fields(data):
        if n == 1 and wt == 2: out['trip'] = _decode_trip_descriptor(v)
        elif n == 2 and wt == 2: out['stop_time_updates'].append(_decode_stop_time_update(v))
        elif n == 3 and wt == 2: out['vehicle'] = _decode_vehicle_descriptor(v)
        elif n == 4 and wt == 0: out['timestamp'] = int(v)
        elif n == 5 and wt == 0: out['delay'] = int(v)
    return out


def _decode_vehicle_position(data: bytes) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for n, wt, v, _ in _fields(data):
        if n == 1 and wt == 2: out['trip'] = _decode_trip_descriptor(v)
        elif n == 2 and wt == 2: out['position'] = _decode_position(v)
        elif n == 3 and wt == 0: out['current_stop_sequence'] = int(v)
        elif n == 4 and wt == 0: out['current_status'] = int(v)
        elif n == 5 and wt == 0: out['timestamp'] = int(v)
        elif n == 6 and wt == 0: out['congestion_level'] = int(v)
        elif n == 7 and wt == 0: out['occupancy_status'] = int(v)
        elif n == 8 and wt == 2: out['vehicle'] = _decode_vehicle_descriptor(v)
        elif n == 9 and wt == 0: out['occupancy_percentage'] = int(v)
        elif n == 10 and wt == 0: out['multi_occupancy_status'] = int(v)
    return out


def _decode_alert_text(data: bytes) -> dict[str, Any]:
    out = {}
    for n, wt, v, _ in _fields(data):
        if n == 1 and wt == 2: out['language'] = _str(v)
        elif n == 2 and wt == 2: out['text'] = _str(v)
    return out


def _decode_alert(data: bytes) -> dict[str, Any]:
    out = {'active_periods': [], 'informed_entities': []}
    for n, wt, v, _ in _fields(data):
        if n == 1 and wt == 2:
            p = {}
            for fn, fwt, fv, _ in _fields(v):
                if fn == 1 and fwt == 0: p['start'] = int(fv)
                elif fn == 2 and fwt == 0: p['end'] = int(fv)
            out['active_periods'].append(p)
        elif n == 5 and wt == 2:
            ent = {}
            for fn, fwt, fv, _ in _fields(v):
                if fn == 1 and fwt == 2: ent['agency_id'] = _str(fv)
                elif fn == 2 and fwt == 2: ent['route_id'] = _str(fv)
                elif fn == 3 and fwt == 2: ent['route_type'] = int.from_bytes(fv, 'little') if isinstance(fv, bytes) else fv
                elif fn == 4 and fwt == 2: ent['trip'] = _decode_trip_descriptor(fv)
                elif fn == 5 and fwt == 2: ent['stop_id'] = _str(fv)
            out['informed_entities'].append(ent)
        elif n == 6 and wt == 0: out['cause'] = int(v)
        elif n == 7 and wt == 0: out['effect'] = int(v)
        elif n == 10 and wt == 2: out['header_text'] = _decode_alert_text(v)
        elif n == 11 and wt == 2: out['description_text'] = _decode_alert_text(v)
    return out


def decode_feed(payload: bytes, kind: str) -> dict[str, Any]:
    header = {}
    entities = []
    for n, wt, v, _ in _fields(payload):
        if n == 1 and wt == 2:
            header = _decode_header(v)
        elif n == 2 and wt == 2:
            ent: dict[str, Any] = {}
            for fn, fwt, fv, _ in _fields(v):
                if fn == 1 and fwt == 2: ent['id'] = _str(fv)
                elif fn == 2 and fwt == 0: ent['is_deleted'] = bool(fv)
                elif fn == 3 and fwt == 2 and kind == 'trip_updates': ent['trip_update'] = _decode_trip_update(fv)
                elif fn == 4 and fwt == 2 and kind == 'vehicle_positions': ent['vehicle'] = _decode_vehicle_position(fv)
                elif fn == 5 and fwt == 2 and kind == 'service_alerts': ent['alert'] = _decode_alert(fv)
            entities.append(ent)
    return {'header': header, 'entity_count': len(entities), 'entities': entities}


def summarise_realtime(feed: dict[str, Any], kind: str) -> dict[str, Any]:
    entities = [e for e in feed.get('entities', []) if not e.get('is_deleted')]
    summary: dict[str, Any] = {'entity_count': len(entities)}
    if kind == 'trip_updates':
        delays = []
        route_ids = set()
        stop_ids = set()
        for e in entities:
            tu = e.get('trip_update', {})
            if tu.get('delay') is not None: delays.append(tu['delay'])
            trip = tu.get('trip', {})
            if trip.get('route_id'): route_ids.add(trip['route_id'])
            for stu in tu.get('stop_time_updates', []):
                if stu.get('stop_id'): stop_ids.add(stu['stop_id'])
                evt = stu.get('arrival') or stu.get('departure') or {}
                if evt.get('delay') is not None: delays.append(evt['delay'])
        summary.update({'routes_affected': len(route_ids), 'stops_mentioned': len(stop_ids), 'avg_delay_sec': round(sum(delays)/len(delays), 1) if delays else 0.0, 'max_delay_sec': max(delays) if delays else 0})
    elif kind == 'vehicle_positions':
        positions = [e.get('vehicle', {}).get('position', {}) for e in entities]
        positioned = [p for p in positions if p.get('latitude') is not None and p.get('longitude') is not None]
        route_ids = {e.get('vehicle', {}).get('trip', {}).get('route_id') for e in entities if e.get('vehicle', {}).get('trip', {}).get('route_id')}
        summary.update({'vehicles': len(entities), 'positioned_vehicles': len(positioned), 'routes_active': len(route_ids)})
    elif kind == 'service_alerts':
        stop_ids=set(); route_ids=set();
        for e in entities:
            for ent in e.get('alert', {}).get('informed_entities', []):
                if ent.get('stop_id'): stop_ids.add(ent['stop_id'])
                if ent.get('route_id'): route_ids.add(ent['route_id'])
        summary.update({'alerts': len(entities), 'routes_affected': len(route_ids), 'stops_affected': len(stop_ids)})
    return summary
