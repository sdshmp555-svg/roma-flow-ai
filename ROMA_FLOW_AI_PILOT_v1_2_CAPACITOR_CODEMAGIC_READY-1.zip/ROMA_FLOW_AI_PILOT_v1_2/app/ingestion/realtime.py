from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import httpx

URLS={
 'trip_updates':'https://romamobilita.it/sites/default/files/rome_rtgtfs_trip_updates_feed.pb',
 'vehicle_positions':'https://romamobilita.it/sites/default/files/rome_rtgtfs_vehicle_positions_feed.pb',
 'service_alerts':'https://romamobilita.it/sites/default/files/rome_rtgtfs_service_alerts_feed.pb',
}

def download_feed(kind:str,out_dir:Path,timeout:float=30)->dict:
    if kind not in URLS: raise ValueError(f'unknown realtime feed: {kind}')
    out_dir.mkdir(parents=True,exist_ok=True)
    url=URLS[kind]
    ts=datetime.now(timezone.utc).isoformat()
    try:
        with httpx.Client(timeout=timeout,follow_redirects=True,headers={'User-Agent':'ROMA-FLOW-AI/0.3'}) as client:
            r=client.get(url); r.raise_for_status(); payload=r.content
        sha=hashlib.sha256(payload).hexdigest()
        path=out_dir/f'rome_rtgtfs_{kind}_feed.pb'
        path.write_bytes(payload)
        return {'source':f'roma_mobilita_gtfs_rt_{kind}','retrieved_at':ts,'status':'ok','bytes_downloaded':len(payload),'sha256':sha,'artifact':str(path)}
    except Exception as exc:
        return {'source':f'roma_mobilita_gtfs_rt_{kind}','retrieved_at':ts,'status':'error','bytes_downloaded':0,'sha256':None,'error':str(exc)}
