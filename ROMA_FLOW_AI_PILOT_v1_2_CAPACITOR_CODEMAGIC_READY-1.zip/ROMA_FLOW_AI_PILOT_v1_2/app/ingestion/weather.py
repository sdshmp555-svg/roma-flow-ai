from __future__ import annotations
from datetime import datetime, timezone
import httpx

OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"


def fetch_weather(lat: float = 41.9028, lon: float = 12.4964, forecast_days: int = 2) -> dict:
    params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": "temperature_2m,precipitation,weather_code",
        "forecast_days": forecast_days,
        "timezone": "Europe/Rome",
    }
    with httpx.Client(timeout=20.0, follow_redirects=True, headers={"User-Agent": "ROMA-FLOW-AI/0.2"}) as client:
        response = client.get(OPEN_METEO_URL, params=params)
        response.raise_for_status()
        payload = response.json()
    payload["romaflow_retrieved_at"] = datetime.now(timezone.utc).isoformat()
    payload["romaflow_source"] = "open-meteo"
    return payload
