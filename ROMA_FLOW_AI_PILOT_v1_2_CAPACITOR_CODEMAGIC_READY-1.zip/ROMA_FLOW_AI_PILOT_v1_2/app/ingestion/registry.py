from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base, SessionLocal

class IngestionRun(Base):
    __tablename__ = "ingestion_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source: Mapped[str] = mapped_column(String, index=True)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String, index=True)
    bytes_downloaded: Mapped[int] = mapped_column(Integer, default=0)
    sha256: Mapped[str | None] = mapped_column(String, nullable=True)
    summary_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)


def record_run(source: str, status: str, *, bytes_downloaded: int = 0, sha256: str | None = None,
               summary_json: str | None = None, error: str | None = None) -> int:
    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        row = IngestionRun(source=source, started_at=now, finished_at=now, status=status,
                           bytes_downloaded=bytes_downloaded, sha256=sha256,
                           summary_json=summary_json, error=error)
        db.add(row)
        db.commit()
        db.refresh(row)
        return row.id
    finally:
        db.close()
